

bl_info = {
    "name": "Hotkey: 'W'",
    "description": "Sculpt Brush Menu",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "W key in Sculpt Mode",
    "warning": "",
    "doc_url": "",
    "category": "Sculpt Pie"
}

import os
import bpy
from bpy.types import (
    Menu,
    Operator,
)


class PIE_OT_SculptSculptDraw(Operator):
    bl_idname = "sculpt.sculptdraw"
    bl_label = "Select Draw Brush"
    bl_description = "Select the Draw sculpt brush"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'SCULPT' and 
                context.active_object and 
                context.active_object.type == 'MESH')

    def execute(self, context):
        try:

            if hasattr(bpy.ops.paint, 'brush_select'):
                bpy.ops.paint.brush_select(sculpt_tool='DRAW')
            else:

                if 'SculptDraw' in bpy.data.brushes:
                    context.tool_settings.sculpt.brush = bpy.data.brushes['SculptDraw']
                elif 'Draw' in bpy.data.brushes:
                    context.tool_settings.sculpt.brush = bpy.data.brushes['Draw']
                else:

                    bpy.ops.brush.add()
                    brush = context.tool_settings.sculpt.brush
                    brush.name = "Draw"
                    brush.sculpt_tool = 'DRAW'
            
            self.report({'INFO'}, "Selected Draw brush")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to select Draw brush: {e}")
            return {'CANCELLED'}


class PIE_MT_SculptPie(Menu):
    bl_idname = "PIE_MT_sculpt"
    bl_label = "Sculpt Brushes"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        pie.scale_y = 1.2
        

        if context.mode != 'SCULPT':
            pie.box().label(text="Switch to Sculpt Mode", icon='SCULPTMODE_HLT')
            return
        

        pie.operator("paint.brush_select", text="Crease", icon='BRUSH_CREASE').sculpt_tool = 'CREASE'
        

        pie.operator("paint.brush_select", text="Blob", icon='BRUSH_BLOB').sculpt_tool = 'BLOB'
        

        pie.menu(PIE_MT_SculptTwo.bl_idname, text="More Brushes", icon='BRUSH_DATA')
        

        pie.operator("sculpt.sculptdraw", text="Draw", icon='BRUSH_SCULPT_DRAW')
        

        pie.operator("paint.brush_select", text="Clay", icon='BRUSH_CLAY').sculpt_tool = 'CLAY'
        

        pie.operator("paint.brush_select", text="Clay Strips", icon='BRUSH_CLAY_STRIPS').sculpt_tool = 'CLAY_STRIPS'
        

        pie.operator("paint.brush_select", text="Inflate", icon='BRUSH_INFLATE').sculpt_tool = 'INFLATE'
        

        pie.menu(PIE_MT_SculptThree.bl_idname, text="Grab Brushes", icon='BRUSH_GRAB')


class PIE_MT_SculptTwo(Menu):
    bl_idname = "PIE_MT_sculpt_two"
    bl_label = "Surface & Smoothing Brushes"

    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.3
        
        layout.label(text="Surface Tools", icon='BRUSH_DATA')
        layout.separator()
        
        layout.operator("paint.brush_select", text="Smooth", 
                       icon='BRUSH_SMOOTH').sculpt_tool = 'SMOOTH'
        layout.operator("paint.brush_select", text="Flatten", 
                       icon='BRUSH_FLATTEN').sculpt_tool = 'FLATTEN'
        layout.operator("paint.brush_select", text="Scrape", 
                       icon='BRUSH_SCRAPE').sculpt_tool = 'SCRAPE'
        
        layout.separator()
        
        layout.operator("paint.brush_select", text="Fill", 
                       icon='BRUSH_FILL').sculpt_tool = 'FILL'
        layout.operator("paint.brush_select", text="Pinch", 
                       icon='BRUSH_PINCH').sculpt_tool = 'PINCH'
        layout.operator("paint.brush_select", text="Layer", 
                       icon='BRUSH_LAYER').sculpt_tool = 'LAYER'
        
        layout.separator()
        
        layout.operator("paint.brush_select", text="Mask", 
                       icon='BRUSH_MASK').sculpt_tool = 'MASK'
        

        if self._brush_exists('SIMPLIFY'):
            layout.operator("paint.brush_select", text="Simplify", 
                           icon='BRUSH_DATA').sculpt_tool = 'SIMPLIFY'

    def _brush_exists(self, tool_name):
        """Check if a sculpt tool exists"""
        try:

            return hasattr(bpy.types, f'SCULPT_OT_{tool_name.lower()}')
        except:
            return False


class PIE_MT_SculptThree(Menu):
    bl_idname = "PIE_MT_sculpt_three"
    bl_label = "Grab & Transform Brushes"

    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.3
        
        layout.label(text="Transform Tools", icon='BRUSH_GRAB')
        layout.separator()
        
        layout.operator("paint.brush_select", text="Grab", 
                       icon='BRUSH_GRAB').sculpt_tool = 'GRAB'
        layout.operator("paint.brush_select", text="Nudge", 
                       icon='BRUSH_NUDGE').sculpt_tool = 'NUDGE'
        layout.operator("paint.brush_select", text="Thumb", 
                       icon='BRUSH_THUMB').sculpt_tool = 'THUMB'
        
        layout.separator()
        
        layout.operator("paint.brush_select", text="Snake Hook", 
                       icon='BRUSH_SNAKE_HOOK').sculpt_tool = 'SNAKE_HOOK'
        layout.operator("paint.brush_select", text="Rotate", 
                       icon='BRUSH_ROTATE').sculpt_tool = 'ROTATE'
        

        if self._brush_exists('POSE'):
            layout.separator()
            layout.operator("paint.brush_select", text="Pose", 
                           icon='BRUSH_DATA').sculpt_tool = 'POSE'
        
        if self._brush_exists('BOUNDARY'):
            layout.operator("paint.brush_select", text="Boundary", 
                           icon='BRUSH_DATA').sculpt_tool = 'BOUNDARY'

    def _brush_exists(self, tool_name):
        """Check if a sculpt tool exists"""
        try:
            return hasattr(bpy.types, f'SCULPT_OT_{tool_name.lower()}')
        except:
            return False


class PIE_OT_ToggleSculptMode(Operator):
    bl_idname = "sculpt.toggle_mode"
    bl_label = "Toggle Sculpt Mode"
    bl_description = "Toggle between Object and Sculpt mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.mode == 'SCULPT':
                bpy.ops.object.mode_set(mode='OBJECT')
                self.report({'INFO'}, "Switched to Object mode")
            else:
                bpy.ops.object.mode_set(mode='SCULPT')
                self.report({'INFO'}, "Switched to Sculpt mode")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to toggle sculpt mode: {e}")
            return {'CANCELLED'}


class PIE_MT_SculptPieEnhanced(Menu):
    bl_idname = "PIE_MT_sculpt_enhanced"
    bl_label = "Sculpt Tools"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        
        obj = context.active_object
        

        if not obj or obj.type != 'MESH':
            pie.box().label(text="Select a Mesh Object", icon='INFO')
            return
        
        if context.mode != 'SCULPT':

            pie.operator("sculpt.toggle_mode", text="Enter Sculpt Mode", icon='SCULPTMODE_HLT')
            for i in range(7):
                pie.separator()
        else:


            pie.operator("paint.brush_select", text="Crease", icon='BRUSH_CREASE').sculpt_tool = 'CREASE'
            

            pie.operator("paint.brush_select", text="Blob", icon='BRUSH_BLOB').sculpt_tool = 'BLOB'
            

            pie.menu(PIE_MT_SculptTwo.bl_idname, text="Surface Tools", icon='BRUSH_DATA')
            

            pie.operator("sculpt.sculptdraw", text="Draw", icon='BRUSH_SCULPT_DRAW')
            

            pie.operator("paint.brush_select", text="Clay", icon='BRUSH_CLAY').sculpt_tool = 'CLAY'
            

            pie.operator("paint.brush_select", text="Clay Strips", icon='BRUSH_CLAY_STRIPS').sculpt_tool = 'CLAY_STRIPS'
            

            pie.operator("paint.brush_select", text="Inflate", icon='BRUSH_INFLATE').sculpt_tool = 'INFLATE'
            

            pie.menu(PIE_MT_SculptThree.bl_idname, text="Transform Tools", icon='BRUSH_GRAB')

classes = (
    PIE_MT_SculptPie,
    PIE_MT_SculptTwo,
    PIE_MT_SculptThree,
    PIE_OT_SculptSculptDraw,
    PIE_OT_ToggleSculptMode,
    PIE_MT_SculptPieEnhanced,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Sculpt')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'W', 'PRESS')
            kmi.properties.name = "PIE_MT_sculpt"
            addon_keymaps.append((km, kmi))
            

            km = wm.keyconfigs.addon.keymaps.new(name='Object Mode')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'W', 'PRESS', shift=True)
            kmi.properties.name = "PIE_MT_sculpt_enhanced"
            addon_keymaps.append((km, kmi))
            
        print("pie_sculpt_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_sculpt_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_sculpt_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_sculpt_menu: {e}")

if __name__ == "__main__":
    register()
