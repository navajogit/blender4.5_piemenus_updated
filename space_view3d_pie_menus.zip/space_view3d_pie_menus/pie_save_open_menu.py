

bl_info = {
    "name": "Hotkey: 'Ctrl S'",
    "description": "Save/Open & File Menus",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "All Editors",
    "warning": "",
    "doc_url": "",
    "category": "Save Open Pie"
}

import bpy
from bpy.types import (
    Menu,
    Operator,
)
import os
import re


class PIE_MT_SaveOpen(Menu):
    bl_idname = "PIE_MT_saveopen"
    bl_label = "Save/Open Files"

    @staticmethod
    def _save_as_mainfile_calc_incremental_name():
        """Calculate incremental filename for save operations"""
        try:
            if not bpy.data.filepath:
                return None
                
            dirname, base_name = os.path.split(bpy.data.filepath)
            base_name_no_ext, ext = os.path.splitext(base_name)
            

            match = re.match(r"(.*)_([\d]+)$", base_name_no_ext)
            if match:
                prefix, number = match.groups()
                number = int(number) + 1
            else:
                prefix, number = base_name_no_ext, 1
            
            prefix = os.path.join(dirname, prefix)
            

            while os.path.isfile(output := "%s_%03d%s" % (prefix, number, ext)):
                number += 1
                
            return output
        except Exception as e:
            print(f"Error calculating incremental name: {e}")
            return None

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        pie.operator("wm.read_homefile", text="New File", icon='FILE_NEW')
        

        pie.menu("PIE_MT_link", text="Link/Append", icon='LINK_BLEND')
        

        pie.menu("PIE_MT_fileio", text="Import/Export", icon='IMPORT')
        

        pie.operator("wm.open_mainfile", text="Open File", icon='FILE_FOLDER')
        

        pie.operator("wm.save_mainfile", text="Save", icon='FILE_TICK')
        

        pie.operator("wm.save_as_mainfile", text="Save As...", icon='EXPORT')
        

        if bpy.data.is_saved and bpy.data.filepath:
            incremental_name = self._save_as_mainfile_calc_incremental_name()
            if incremental_name:

                default_context = layout.operator_context
                layout.operator_context = 'EXEC_DEFAULT'
                
                op = pie.operator("wm.save_as_mainfile", text="Incremental Save", icon='PLUS')
                op.filepath = incremental_name
                op.check_existing = False
                
                layout.operator_context = default_context
            else:
                pie.box().label(text="Incremental Save (error)", icon='ERROR')
        else:
            pie.box().label(text="Incremental Save (unsaved)", icon='INFO')


        pie.menu("PIE_MT_recover", text="Recovery", icon='RECOVER_LAST')


class PIE_MT_Link(Menu):
    bl_idname = "PIE_MT_link"
    bl_label = "Link & Append"

    def draw(self, context):
        layout = self.layout
        

        layout.label(text="File Operations", icon='LINK_BLEND')
        layout.operator("wm.link", text="Link Objects/Data", icon='LINK_BLEND')
        layout.operator("wm.append", text="Append Objects/Data", icon='APPEND_BLEND')
        
        layout.separator()
        

        layout.label(text="Pack Resources", icon='PACKAGE')
        

        if hasattr(bpy.ops.file, 'autopack_toggle'):
            layout.operator("file.autopack_toggle", text="Auto Pack Toggle")
        else:

            layout.prop(context.blend_data, "use_autopack", text="Auto Pack Resources")
            
        layout.operator("file.pack_all", text="Pack All Resources")
        layout.operator("file.unpack_all", text="Unpack All Resources")
        
        layout.separator()
        

        layout.label(text="File Paths", icon='FILE_FOLDER')
        layout.operator("file.make_paths_relative", text="Make Paths Relative")
        layout.operator("file.make_paths_absolute", text="Make Paths Absolute")
        

        if hasattr(bpy.ops.file, 'report_missing_files'):
            layout.separator()
            layout.operator("file.report_missing_files", text="Report Missing Files")


class PIE_MT_Recover(Menu):
    bl_idname = "PIE_MT_recover"
    bl_label = "Recovery Options"

    def draw(self, context):
        layout = self.layout
        
        layout.label(text="Recovery Options", icon='RECOVER_LAST')
        

        layout.operator("wm.recover_auto_save", text="Recover Auto Save...", icon='RECOVER_AUTO')
        layout.operator("wm.recover_last_session", text="Recover Last Session", icon='RECOVER_LAST')
        
        layout.separator()
        

        layout.operator("wm.revert_mainfile", text="Revert to Saved", icon='FILE_REFRESH')
        
        layout.separator()
        

        if hasattr(bpy.ops.file, 'report_missing_files'):
            layout.operator("file.report_missing_files", text="Report Missing Files", icon='ERROR')
        
        if hasattr(bpy.ops.file, 'find_missing_files'):
            layout.operator("file.find_missing_files", text="Find Missing Files", icon='VIEWZOOM')
        
        layout.separator()
        

        layout.label(text="Backup Options", icon='FILE_BACKUP')
        recent_files = bpy.utils.preset_paths("recent-files.txt")
        if recent_files:
            layout.operator("wm.call_menu", text="Recent Files", icon='TIME').name = "TOPBAR_MT_file_open_recent"


class PIE_MT_FileIO(Menu):
    bl_idname = "PIE_MT_fileio"
    bl_label = "Import/Export"

    def draw(self, context):
        layout = self.layout
        

        layout.label(text="Import", icon='IMPORT')
        

        try:
            layout.menu("TOPBAR_MT_file_import", text="Import Menu", icon='IMPORT')
        except:

            layout.operator("wm.obj_import", text="Import OBJ", icon='IMPORT')
            layout.operator("wm.collada_import", text="Import COLLADA", icon='IMPORT')
            if hasattr(bpy.ops.import_scene, 'fbx'):
                layout.operator("import_scene.fbx", text="Import FBX", icon='IMPORT')
        
        layout.separator()
        

        layout.label(text="Export", icon='EXPORT')
        

        try:
            layout.menu("TOPBAR_MT_file_export", text="Export Menu", icon='EXPORT')
        except:

            layout.operator("wm.obj_export", text="Export OBJ", icon='EXPORT')
            layout.operator("wm.collada_export", text="Export COLLADA", icon='EXPORT')
            if hasattr(bpy.ops.export_scene, 'fbx'):
                layout.operator("export_scene.fbx", text="Export FBX", icon='EXPORT')
        
        layout.separator()
        

        layout.label(text="Quick Export", icon='EXPORT')
        if bpy.data.filepath:
            base_name = os.path.splitext(os.path.basename(bpy.data.filepath))[0]
            if hasattr(bpy.ops.export_scene, 'obj'):
                op = layout.operator("export_scene.obj", text=f"Export {base_name}.obj", icon='EXPORT')
                op.filepath = os.path.join(os.path.dirname(bpy.data.filepath), f"{base_name}.obj")


class PIE_OT_OpenRecent(Operator):
    bl_idname = "file.open_recent_pie"
    bl_label = "Open Recent File"
    bl_description = "Open the most recently used file"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        try:

            import bpy.utils
            recent_files = []
            

            if hasattr(context.preferences, 'filepaths'):
                recent_files = context.preferences.filepaths.recent_files
            
            if recent_files and len(recent_files) > 0:
                most_recent = recent_files[0].name
                if os.path.exists(most_recent):
                    bpy.ops.wm.open_mainfile(filepath=most_recent)
                    self.report({'INFO'}, f"Opened: {os.path.basename(most_recent)}")
                    return {'FINISHED'}
            

            bpy.ops.wm.call_menu(name="TOPBAR_MT_file_open_recent")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to open recent file: {e}")
            return {'CANCELLED'}

classes = (
    PIE_MT_SaveOpen,
    PIE_MT_FileIO,
    PIE_MT_Recover,
    PIE_MT_Link,
    PIE_OT_OpenRecent,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Window')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'S', 'PRESS', ctrl=True)
            kmi.properties.name = "PIE_MT_saveopen"
            addon_keymaps.append((km, kmi))
            
        print("pie_save_open_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_save_open_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_save_open_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_save_open_menu: {e}")

if __name__ == "__main__":
    register()
