

bl_info = {
    "name": "Hotkey: 'Ctrl Alt S'",
    "description": "Switch Editor Type Menu",
    "author": "saidenka, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "All Editors",
    "warning": "",
    "doc_url": "",
    "category": "Editor Switch Pie"
}

import bpy
from bpy.types import (
    Menu,
    Operator,
)
from bpy.props import (
    StringProperty,
)


class PIE_MT_AreaPieEditor(Menu):
    bl_idname = "PIE_MT_editor"
    bl_label = "Editor Switch"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        pie.operator(PIE_OT_SetAreaType.bl_idname,
                     text="Video Sequence Editor", icon="SEQUENCE").types = "SEQUENCE_EDITOR"
        

        pie.menu(PIE_MT_AreaTypePieNode.bl_idname, text="Node Editors", icon="NODETREE")
        

        pie.menu(PIE_MT_AreaTypePieOther.bl_idname, text="Script/Data Editors", icon="PREFERENCES")
        

        pie.operator(PIE_OT_SetAreaType.bl_idname, text="3D Viewport", icon="VIEW3D").types = "VIEW_3D"
        

        pie.operator(PIE_OT_SetAreaType.bl_idname, text="Image Editor", icon="IMAGE").types = "IMAGE_EDITOR"
        

        pie.operator(PIE_OT_SetAreaType.bl_idname, text="UV Editor", icon="UV").types = "UV"
        

        pie.operator(PIE_OT_SetAreaType.bl_idname,
                     text="Movie Clip Editor", icon="TRACKER").types = "CLIP_EDITOR"
        

        pie.menu(PIE_MT_AreaTypePieAnim.bl_idname, text="Animation Editors", icon="ACTION")


class PIE_MT_AreaTypePieOther(Menu):
    bl_idname = "PIE_MT_area_type_other"
    bl_label = "Script & Data Editors"
    bl_description = "Change to script and data editors"

    def draw(self, context):
        layout = self.layout
        
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="Outliner", icon="OUTLINER").types = "OUTLINER"
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="Properties", icon="PROPERTIES").types = "PROPERTIES"
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="File Browser", icon="FILEBROWSER").types = "FILE_BROWSER"
        layout.separator()
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="Preferences", icon="PREFERENCES").types = "PREFERENCES"
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="Text Editor", icon="TEXT").types = "TEXT_EDITOR"
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="Python Console", icon="CONSOLE").types = "CONSOLE"
        layout.separator()
        

        if hasattr(bpy.types, 'INFO_HT_header'):
            layout.operator(PIE_OT_SetAreaType.bl_idname, text="Info", icon="INFO").types = "INFO"


class PIE_MT_AreaTypePieNode(Menu):
    bl_idname = "PIE_MT_area_type_node"
    bl_label = "Node Editors"
    bl_description = "Change to node editors"

    def draw(self, context):
        layout = self.layout
        

        layout.operator(PIE_OT_SetNodeEditor.bl_idname, text="Shader Editor", 
                       icon="NODE_MATERIAL").node_type = "ShaderNodeTree"
        layout.operator(PIE_OT_SetNodeEditor.bl_idname, text="Compositor", 
                       icon="NODE_COMPOSITING").node_type = "CompositorNodeTree"
        layout.operator(PIE_OT_SetNodeEditor.bl_idname, text="Texture Nodes", 
                       icon="NODE_TEXTURE").node_type = "TextureNodeTree"
        layout.separator()
        

        if hasattr(bpy.types, 'GeometryNodeTree'):
            layout.operator(PIE_OT_SetNodeEditor.bl_idname, text="Geometry Nodes", 
                           icon="GEOMETRY_NODES").node_type = "GeometryNodeTree"


class PIE_MT_AreaTypePieAnim(Menu):
    bl_idname = "PIE_MT_area_type_anim"
    bl_label = "Animation Editors"
    bl_description = "Change to animation editors"

    def draw(self, context):
        layout = self.layout
        
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="Dope Sheet", icon="ACTION").types = "DOPESHEET"
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="Timeline", icon="TIME").types = "TIMELINE"
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="Graph Editor", icon="GRAPH").types = "FCURVES"
        layout.separator()
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="Drivers", icon="DRIVER").types = "DRIVERS"
        layout.operator(PIE_OT_SetAreaType.bl_idname, text="NLA Editor", icon="NLA").types = "NLA_EDITOR"


class PIE_OT_SetAreaType(Operator):
    bl_idname = "wm.set_area_type"
    bl_label = "Change Editor Type"
    bl_description = "Change the current area to selected editor type"
    bl_options = {'REGISTER'}

    types: StringProperty(name="Area Type")

    @classmethod
    def poll(cls, context):
        return context.area is not None

    def execute(self, context):
        try:
            if context.area:

                valid_types = {
                    'VIEW_3D', 'IMAGE_EDITOR', 'UV', 'SEQUENCE_EDITOR', 'CLIP_EDITOR',
                    'DOPESHEET', 'TIMELINE', 'FCURVES', 'DRIVERS', 'NLA_EDITOR',
                    'TEXT_EDITOR', 'CONSOLE', 'INFO', 'OUTLINER', 'PROPERTIES',
                    'FILE_BROWSER', 'PREFERENCES', 'NODE_EDITOR'
                }
                
                if self.types in valid_types:
                    context.area.ui_type = self.types
                    self.report({'INFO'}, f"Changed to {self.types.replace('_', ' ').title()}")
                else:
                    self.report({'WARNING'}, f"Editor type {self.types} not available")
                    return {'CANCELLED'}
                    
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to change editor type: {e}")
            return {'CANCELLED'}


class PIE_OT_SetNodeEditor(Operator):
    bl_idname = "wm.set_node_editor"
    bl_label = "Change to Node Editor"
    bl_description = "Change to specific node editor type"
    bl_options = {'REGISTER'}

    node_type: StringProperty(name="Node Type")

    @classmethod
    def poll(cls, context):
        return context.area is not None

    def execute(self, context):
        try:
            if context.area:

                context.area.ui_type = 'NODE_EDITOR'
                

                if hasattr(context.area, 'spaces') and context.area.spaces.active:
                    space = context.area.spaces.active
                    if hasattr(space, 'tree_type'):
                        space.tree_type = self.node_type
                        

                        if hasattr(space, 'node_tree'):
                            if self.node_type == 'ShaderNodeTree':
                                space.shader_type = 'OBJECT'
                            elif self.node_type == 'CompositorNodeTree':
                                if context.scene.use_nodes == False:
                                    context.scene.use_nodes = True
                
                node_name = self.node_type.replace('NodeTree', '').replace('Tree', '')
                self.report({'INFO'}, f"Changed to {node_name} Editor")
                
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to change to node editor: {e}")
            return {'CANCELLED'}


class PIE_OT_Timeline(Operator):
    bl_idname = "wm.set_timeline"
    bl_label = "Change to Timeline"
    bl_description = "Change to Timeline Editor"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.area is not None

    def execute(self, context):
        try:
            if context.area:
                context.area.ui_type = 'TIMELINE'
                self.report({'INFO'}, "Changed to Timeline")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to change to timeline: {e}")
            return {'CANCELLED'}

classes = (
    PIE_MT_AreaPieEditor,
    PIE_MT_AreaTypePieOther,
    PIE_MT_AreaTypePieNode,
    PIE_MT_AreaTypePieAnim,
    PIE_OT_SetAreaType,
    PIE_OT_SetNodeEditor,
    PIE_OT_Timeline,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Window')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'S', 'PRESS', ctrl=True, alt=True)
            kmi.properties.name = "PIE_MT_editor"
            addon_keymaps.append((km, kmi))
            
        print("pie_editor_switch_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_editor_switch_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_editor_switch_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_editor_switch_menu: {e}")

if __name__ == "__main__":
    register()
