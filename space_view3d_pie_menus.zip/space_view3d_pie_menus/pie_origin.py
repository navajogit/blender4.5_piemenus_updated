

bl_info = {
    "name": "Hotkey: 'Ctrl Alt X'",
    "description": "Origin Snap/Place Menu",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "3D View",
    "warning": "",
    "doc_url": "",
    "category": "Origin Pie"
}

import bpy
import bmesh
from bpy.types import (
    Menu,
    Operator,
)


class PIE_OT_PivotToSelection(Operator):
    bl_idname = "object.pivot2selection"
    bl_label = "Pivot To Selection"
    bl_description = "Pivot Point To Selection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        try:
            saved_location = context.scene.cursor.location.copy()
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            context.scene.cursor.location = saved_location
            self.report({'INFO'}, "Origin set to selection")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set pivot to selection: {e}")
            return {'CANCELLED'}


class PIE_OT_PivotBottom(Operator):
    bl_idname = "object.pivotobottom"
    bl_label = "Pivot To Bottom"
    bl_description = ("Set the Pivot Point To Lowest Point\n"
                      "Needs an Active Object of the Mesh type")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        try:
            obj = context.active_object
            

            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
            

            mesh = obj.data
            if len(mesh.vertices) == 0:
                self.report({'WARNING'}, "Object has no vertices")
                return {'CANCELLED'}
            

            min_z = min(v.co.z for v in mesh.vertices)
            

            for vertex in mesh.vertices:
                vertex.co.z -= min_z
            

            obj.location.z += min_z
            

            mesh.update()
            
            self.report({'INFO'}, "Origin set to bottom")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set pivot to bottom: {e}")
            return {'CANCELLED'}


class PIE_OT_PivotBottom_edit(Operator):
    bl_idname = "object.pivotobottom_edit"
    bl_label = "Pivot To Bottom"
    bl_description = ("Set the Pivot Point To Lowest Point\n"
                      "Needs an Active Object of the Mesh type")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        try:
            original_mode = context.mode
            bpy.ops.object.mode_set(mode='OBJECT')
            

            result = bpy.ops.object.pivotobottom()
            

            if 'FINISHED' in result:
                bpy.ops.object.mode_set(mode='EDIT')
                return {'FINISHED'}
            else:
                return {'CANCELLED'}
                
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set pivot to bottom in edit mode: {e}")
            return {'CANCELLED'}


class PIE_OT_PivotToCursor_edit(Operator):
    bl_idname = "object.pivot2cursor_edit"
    bl_label = "Pivot To Cursor"
    bl_description = "Pivot Point To Cursor"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            bpy.ops.object.mode_set(mode='EDIT')
            self.report({'INFO'}, "Origin set to cursor")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set pivot to cursor: {e}")
            return {'CANCELLED'}


class PIE_OT_OriginToMass_edit(Operator):
    bl_idname = "object.origintomass_edit"
    bl_label = "Origin to Center of Mass"
    bl_description = "Origin to Center of Mass"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')
            bpy.ops.object.mode_set(mode='EDIT')
            self.report({'INFO'}, "Origin set to center of mass")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set origin to mass: {e}")
            return {'CANCELLED'}


class PIE_OT_OriginToGeometry_edit(Operator):
    bl_idname = "object.origintogeometry_edit"
    bl_label = "Origin to Geometry"
    bl_description = "Origin to Geometry"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
            bpy.ops.object.mode_set(mode='EDIT')
            self.report({'INFO'}, "Origin set to geometry")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set origin to geometry: {e}")
            return {'CANCELLED'}


class PIE_OT_GeometryToOrigin_edit(Operator):
    bl_idname = "object.geometrytoorigin_edit"
    bl_label = "Geometry to Origin"
    bl_description = "Geometry to Origin"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.origin_set(type='GEOMETRY_ORIGIN', center='MEDIAN')
            bpy.ops.object.mode_set(mode='EDIT')
            self.report({'INFO'}, "Geometry moved to origin")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set geometry to origin: {e}")
            return {'CANCELLED'}


def vfeOrigin_pie(context):
    """Ustawia origin na zaznaczenie w trybie edit"""
    try:

        cursor_location = context.scene.cursor.location.copy()
        

        bpy.ops.view3d.snap_cursor_to_selected()
        

        bpy.ops.object.mode_set(mode='OBJECT')
        

        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        

        bpy.ops.object.mode_set(mode='EDIT')
        

        context.scene.cursor.location = cursor_location
        
        return True
        
    except Exception as e:
        print(f"Error in vfeOrigin_pie: {e}")
        return False

class PIE_OT_SetOriginToSelected_edit(Operator):
    bl_idname = "object.setorigintoselected_edit"
    bl_label = "Set Origin to Selected"
    bl_description = "Set Origin to Selected"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.area.type == "VIEW_3D" and 
                context.active_object is not None and
                context.mode == 'EDIT_MESH')

    def execute(self, context):
        if not vfeOrigin_pie(context):
            self.report({"ERROR"}, "Set Origin to Selected could not be performed")
            return {'CANCELLED'}
        
        self.report({'INFO'}, "Origin set to selected")
        return {'FINISHED'}


class PIE_MT_OriginPivot(Menu):
    bl_idname = "ORIGIN_MT_pivotmenu"
    bl_label = "Origin Menu"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        pie = layout.menu_pie()
        
        if obj and obj.type == 'MESH' and obj.mode == 'OBJECT':

            pie.operator("object.origin_set", text="Origin to Center of Mass",
                         icon='PIVOT_MEDIAN').type = 'ORIGIN_CENTER_OF_MASS'

            pie.operator("object.origin_set", text="Origin to Cursor",
                        icon='PIVOT_CURSOR').type = 'ORIGIN_CURSOR'

            pie.operator("object.pivotobottom", text="Origin to Bottom",
                        icon='TRIA_DOWN')

            pie.operator("object.pivot2selection", text="Origin To Selection",
                        icon='SNAP_INCREMENT')

            pie.operator("object.origin_set", text="Geometry To Origin",
                        icon='PIVOT_BOUNDBOX').type = 'GEOMETRY_ORIGIN'

            pie.operator("object.origin_set", text="Origin To Geometry",
                        icon='PIVOT_BOUNDBOX').type = 'ORIGIN_GEOMETRY'

        elif obj and obj.type == 'MESH' and obj.mode == 'EDIT':

            pie.operator("object.origintomass_edit", text="Origin to Center of Mass",
                         icon='PIVOT_MEDIAN')

            pie.operator("object.pivot2cursor_edit", text="Origin to Cursor",
                        icon='PIVOT_CURSOR')

            pie.operator("object.pivotobottom_edit", text="Origin to Bottom",
                        icon='TRIA_DOWN')

            pie.operator("object.setorigintoselected_edit", text="Origin To Selected",
                        icon='SNAP_INCREMENT')

            pie.operator("object.geometrytoorigin_edit", text="Geometry To Origin",
                        icon='PIVOT_BOUNDBOX')

            pie.operator("object.origintogeometry_edit", text="Origin To Geometry",
                        icon='PIVOT_BOUNDBOX')

        else:


            pie.operator("object.origin_set", text="Origin to Center of Mass",
                         icon='PIVOT_MEDIAN').type = 'ORIGIN_CENTER_OF_MASS'

            pie.operator("object.origin_set", text="Origin To 3D Cursor",
                        icon='PIVOT_CURSOR').type = 'ORIGIN_CURSOR'

            pie.operator("object.pivot2selection", text="Origin To Selection",
                        icon='SNAP_INCREMENT')

            pie.operator("object.origin_set", text="Origin To Geometry",
                        icon='PIVOT_BOUNDBOX').type = 'ORIGIN_GEOMETRY'

            pie.operator("object.origin_set", text="Geometry To Origin",
                        icon='PIVOT_BOUNDBOX').type = 'GEOMETRY_ORIGIN'

            pie.separator()

classes = (
    PIE_MT_OriginPivot,
    PIE_OT_PivotToSelection,
    PIE_OT_PivotBottom,
    PIE_OT_PivotToCursor_edit,
    PIE_OT_OriginToMass_edit,
    PIE_OT_PivotBottom_edit,
    PIE_OT_OriginToGeometry_edit,
    PIE_OT_GeometryToOrigin_edit,
    PIE_OT_SetOriginToSelected_edit
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='3D View Generic', space_type='VIEW_3D')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS', ctrl=True, alt=True)
            kmi.properties.name = "ORIGIN_MT_pivotmenu"
            addon_keymaps.append((km, kmi))
            
        print("pie_origin registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_origin: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_origin unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_origin: {e}")

if __name__ == "__main__":
    register()
