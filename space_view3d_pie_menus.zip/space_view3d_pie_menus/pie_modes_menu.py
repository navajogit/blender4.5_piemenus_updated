

bl_info = {
    "name": "Hotkey: 'Ctrl Tab'",
    "description": "Switch between 3D view object/edit modes",
    "author": "pitiwazou, meta-androcto, italic (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "3D View",
    "warning": "",
    "doc_url": "",
    "category": "Mode Switch Pie"
}

import bpy
from bpy.types import (
    Menu,
    Operator
)


class PIE_OT_ClassObject(Operator):
    bl_idname = "class.object"
    bl_label = "Object/Edit Toggle"
    bl_description = "Toggle between Edit and Object Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        try:
            if context.object.mode == "OBJECT":
                bpy.ops.object.mode_set(mode="EDIT")
            else:
                bpy.ops.object.mode_set(mode="OBJECT")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to toggle mode: {e}")
            return {'CANCELLED'}


class PIE_OT_ClassTexturePaint(Operator):
    bl_idname = "class.pietexturepaint"
    bl_label = "Texture Paint Mode"
    bl_description = "Switch to Texture Paint Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode == "EDIT":
                bpy.ops.object.mode_set(mode="OBJECT")
            

            if hasattr(bpy.ops.paint, 'texture_paint_toggle'):
                bpy.ops.paint.texture_paint_toggle()
            else:
                bpy.ops.object.mode_set(mode="TEXTURE_PAINT")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to enter texture paint: {e}")
            return {'CANCELLED'}


class PIE_OT_ClassWeightPaint(Operator):
    bl_idname = "class.pieweightpaint"
    bl_label = "Weight Paint Mode"
    bl_description = "Switch to Weight Paint Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode == "EDIT":
                bpy.ops.object.mode_set(mode="OBJECT")
            
            if hasattr(bpy.ops.paint, 'weight_paint_toggle'):
                bpy.ops.paint.weight_paint_toggle()
            else:
                bpy.ops.object.mode_set(mode="WEIGHT_PAINT")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to enter weight paint: {e}")
            return {'CANCELLED'}


class PIE_OT_ClassVertexPaint(Operator):
    bl_idname = "class.pievertexpaint"
    bl_label = "Vertex Paint Mode"
    bl_description = "Switch to Vertex Paint Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode == "EDIT":
                bpy.ops.object.mode_set(mode="OBJECT")
            
            if hasattr(bpy.ops.paint, 'vertex_paint_toggle'):
                bpy.ops.paint.vertex_paint_toggle()
            else:
                bpy.ops.object.mode_set(mode="VERTEX_PAINT")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to enter vertex paint: {e}")
            return {'CANCELLED'}


class PIE_OT_ClassParticleEdit(Operator):
    bl_idname = "class.pieparticleedit"
    bl_label = "Particle Edit Mode"
    bl_description = "Switch to Particle Edit Mode (requires active particle system)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH' and 
                hasattr(obj, 'particle_systems') and 
                len(obj.particle_systems) > 0)

    def execute(self, context):
        try:
            if context.object.mode == "EDIT":
                bpy.ops.object.mode_set(mode="OBJECT")
            
            if hasattr(bpy.ops.particle, 'particle_edit_toggle'):
                bpy.ops.particle.particle_edit_toggle()
            else:
                bpy.ops.object.mode_set(mode="PARTICLE_EDIT")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to enter particle edit: {e}")
            return {'CANCELLED'}


class PIE_OT_SetObjectModePie(Operator):
    bl_idname = "object.set_object_mode_pie"
    bl_label = "Set Object Mode"
    bl_description = "Set the interactive mode of the active object"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.StringProperty(name="Mode", default="OBJECT")

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        try:
            if context.active_object:
                bpy.ops.object.mode_set(mode=self.mode)
                return {'FINISHED'}
            else:
                self.report({'WARNING'}, "No active object selected")
                return {'CANCELLED'}
        except Exception as e:
            obj_name = context.active_object.name if context.active_object else "Unknown"
            self.report({'WARNING'}, f"Cannot set mode {self.mode} for {obj_name}: {e}")
            return {'CANCELLED'}


class PIE_OT_ClassVertex(Operator):
    bl_idname = "class.vertex"
    bl_label = "Vertex Select Mode"
    bl_description = "Switch to Vertex Selection Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode != "EDIT":
                bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set vertex mode: {e}")
            return {'CANCELLED'}

class PIE_OT_ClassEdge(Operator):
    bl_idname = "class.edge"
    bl_label = "Edge Select Mode"
    bl_description = "Switch to Edge Selection Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode != "EDIT":
                bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set edge mode: {e}")
            return {'CANCELLED'}

class PIE_OT_ClassFace(Operator):
    bl_idname = "class.face"
    bl_label = "Face Select Mode"
    bl_description = "Switch to Face Selection Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode != "EDIT":
                bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set face mode: {e}")
            return {'CANCELLED'}

class PIE_OT_VertsEdgesFaces(Operator):
    bl_idname = "verts.edgesfaces"
    bl_label = "Multi-Select Mode"
    bl_description = "Enable Vertex/Edge/Face Selection Mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode != "EDIT":
                bpy.ops.object.mode_set(mode="EDIT")
            

            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
            bpy.ops.mesh.select_mode(use_extend=True, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_mode(use_extend=True, use_expand=False, type='FACE')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set multi-select mode: {e}")
            return {'CANCELLED'}


class PIE_MT_ObjectEditOtherModes(Menu):
    bl_idname = "PIE_MT_edit_selection_modes"
    bl_label = "Edit Selection Modes"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        box = pie.split().column()
        box.operator("class.vertex", text="Vertex", icon='VERTEXSEL')
        box.operator("class.edge", text="Edge", icon='EDGESEL')
        box.operator("class.face", text="Face", icon='FACESEL')
        box.separator()
        box.operator("verts.edgesfaces", text="Vertex/Edge/Face", icon='OBJECT_DATAMODE')


class PIE_MT_ObjectEditMode(Menu):
    bl_idname = "PIE_MT_objecteditmode"
    bl_label = "Mode Switch"

    def draw(self, context):
        layout = self.layout
        ob = context.active_object
        

        if not ob or not ob.select_get():
            pie = layout.menu_pie()
            for i in range(7):
                pie.separator()
            box = pie.box()
            box.label(text="No Active Object Selected", icon="INFO")
            return


        if ob.type == 'MESH':
            pie = layout.menu_pie()
            

            pie.operator("class.pieweightpaint", text="Weight Paint", icon='WPAINT_HLT')

            pie.operator("class.pietexturepaint", text="Texture Paint", icon='TPAINT_HLT')

            pie.menu("PIE_MT_edit_selection_modes", text="Edit Modes", icon='EDITMODE_HLT')

            pie.operator("class.object", text="Object/Edit Toggle", icon='OBJECT_DATAMODE')

            if hasattr(bpy.ops.sculpt, 'sculptmode_toggle'):
                pie.operator("sculpt.sculptmode_toggle", text="Sculpt", icon='SCULPTMODE_HLT')
            else:
                pie.operator("object.set_object_mode_pie", text="Sculpt", icon='SCULPTMODE_HLT').mode = "SCULPT"

            pie.operator("class.pievertexpaint", text="Vertex Paint", icon='VPAINT_HLT')

            pie.separator()

            if hasattr(ob, 'particle_systems') and len(ob.particle_systems) > 0:
                pie.operator("class.pieparticleedit", text="Particle Edit", icon='PARTICLEMODE')
            else:
                pie.separator()


        elif ob.type == 'CURVE':
            pie = layout.menu_pie()
            for i in range(7):
                pie.separator()

            if hasattr(bpy.ops.object, 'editmode_toggle'):
                pie.operator("object.editmode_toggle", text="Edit/Object Toggle", icon='OBJECT_DATAMODE')
            else:
                pie.operator("object.set_object_mode_pie", text="Edit Mode", icon='EDITMODE_HLT').mode = "EDIT"


        elif ob.type == 'ARMATURE':
            pie = layout.menu_pie()

            pie.operator("object.set_object_mode_pie", text="Object", icon="OBJECT_DATAMODE").mode = "OBJECT"

            pie.operator("object.set_object_mode_pie", text="Pose", icon="POSE_HLT").mode = "POSE" 

            pie.operator("object.set_object_mode_pie", text="Edit", icon="EDITMODE_HLT").mode = "EDIT"

            if hasattr(bpy.ops.object, 'editmode_toggle'):
                pie.operator("object.editmode_toggle", text="Edit Mode", icon='OBJECT_DATAMODE')
            else:
                pie.operator("object.set_object_mode_pie", text="Edit Mode", icon='EDITMODE_HLT').mode = "EDIT"
            for i in range(4):
                pie.separator()


        elif ob.type == 'GPENCIL':
            pie = layout.menu_pie()

            pie.operator("object.set_object_mode_pie", text="Sculpt", icon="SCULPTMODE_HLT").mode = "SCULPT_GPENCIL"

            pie.operator("object.set_object_mode_pie", text="Draw", icon="GREASEPENCIL").mode = "PAINT_GPENCIL"

            pie.operator("object.set_object_mode_pie", text="Edit", icon="EDITMODE_HLT").mode = "EDIT_GPENCIL"

            pie.operator("object.set_object_mode_pie", text="Object", icon="OBJECT_DATAMODE").mode = "OBJECT"

            pie.separator()

            pie.separator()

            pie.separator()

            pie.operator("object.set_object_mode_pie", text="Weight Paint", icon="WPAINT_HLT").mode = "WEIGHT_GPENCIL"


        elif ob.type in {'FONT', 'SURFACE', 'META', 'LATTICE'}:
            pie = layout.menu_pie()
            for i in range(7):
                pie.separator()

            if hasattr(bpy.ops.object, 'editmode_toggle'):
                pie.operator("object.editmode_toggle", text="Edit/Object Toggle", icon='OBJECT_DATAMODE')
            else:
                pie.operator("object.set_object_mode_pie", text="Edit Mode", icon='EDITMODE_HLT').mode = "EDIT"


        elif ob.type in {"LIGHT", "CAMERA", "EMPTY", "SPEAKER"}:
            pie = layout.menu_pie()
            for i in range(7):
                pie.separator()
            box = pie.box()
            box.label(text="Active Object has only Object Mode available", icon="INFO")

classes = (
    PIE_MT_ObjectEditMode,
    PIE_OT_ClassObject,
    PIE_OT_ClassVertex,
    PIE_OT_ClassEdge,
    PIE_OT_ClassFace,
    PIE_MT_ObjectEditOtherModes,
    PIE_OT_ClassTexturePaint,
    PIE_OT_ClassWeightPaint,
    PIE_OT_ClassVertexPaint,
    PIE_OT_ClassParticleEdit,
    PIE_OT_VertsEdgesFaces,
    PIE_OT_SetObjectModePie,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Object Non-modal')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'TAB', 'PRESS', ctrl=True)
            kmi.properties.name = "PIE_MT_objecteditmode"
            addon_keymaps.append((km, kmi))


            km = wm.keyconfigs.addon.keymaps.new(name='Grease Pencil Stroke Edit Mode')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'TAB', 'PRESS', ctrl=True)
            kmi.properties.name = "PIE_MT_objecteditmode"
            addon_keymaps.append((km, kmi))
            
        print("pie_modes_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_modes_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_modes_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_modes_menu: {e}")

if __name__ == "__main__":
    register()
