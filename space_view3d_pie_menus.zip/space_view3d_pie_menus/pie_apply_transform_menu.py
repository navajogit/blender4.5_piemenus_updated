

bl_info = {
    "name": "Hotkey: 'Ctrl A'",
    "description": "Apply Transform Menu",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "3D View",
    "warning": "",
    "doc_url": "",
    "category": "Apply Transform Pie"
}

import bpy
from bpy.types import (
    Menu,
    Operator,
)
from bpy.props import EnumProperty


class PIE_MT_PieApplyTransforms(Menu):
    bl_idname = "PIE_MT_applytransforms"
    bl_label = "Pie Apply Transforms"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        pie.operator("object.visual_transform_apply", text="Apply Visual", icon='OBJECT_ORIGIN')
        

        props = pie.operator("object.transform_apply", text="Apply All", icon='CHECKMARK')
        props.location, props.rotation, props.scale = (True, True, True)
        

        props = pie.operator("object.transform_apply", text="Rotation/Scale", icon='EMPTY_ARROWS')
        props.location, props.rotation, props.scale = (False, True, True)
        

        props = pie.operator("object.transform_apply", text="Rotation", icon='ORIENTATION_GIMBAL')
        props.location, props.rotation, props.scale = (False, True, False)
        

        props = pie.operator("object.transform_apply", text="Location", icon='OBJECT_ORIGIN')
        props.location, props.rotation, props.scale = (True, False, False)
        

        props = pie.operator("object.transform_apply", text="Scale", icon='FULLSCREEN_EXIT')
        props.location, props.rotation, props.scale = (False, False, True)
        

        if hasattr(bpy.ops.object, 'duplicates_make_real'):
            pie.operator("object.duplicates_make_real", text="Make Instances Real", icon='DUPLICATE')
        else:

            pie.operator("object.make_single_user", text="Make Single User", icon='DUPLICATE').object = True
        

        pie.menu("PIE_MT_clear_menu", text="Clear Transform Menu", icon='PANEL_CLOSE')


class PIE_MT_ClearMenu(Menu):
    bl_idname = "PIE_MT_clear_menu"
    bl_label = "Clear Menu"

    def draw(self, context):
        layout = self.layout
        
        layout.operator("clear.all", text="Clear All", icon='X')
        layout.separator()
        layout.operator("object.location_clear", text="Clear Location", icon='OBJECT_ORIGIN')
        layout.operator("object.rotation_clear", text="Clear Rotation", icon='ORIENTATION_GIMBAL')
        layout.operator("object.scale_clear", text="Clear Scale", icon='FULLSCREEN_EXIT')
        layout.separator()
        layout.operator("object.origin_clear", text="Clear Origin", icon='OBJECT_ORIGIN')


class PIE_OT_ClearAll(Operator):
    bl_idname = "clear.all"
    bl_label = "Clear All"
    bl_description = "Clear All Transforms (Location, Rotation, Scale)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        try:

            selected_objects = context.selected_objects
            if not selected_objects:
                self.report({'WARNING'}, "No objects selected")
                return {'CANCELLED'}
            

            success_count = 0
            
            for obj in selected_objects:
                context.view_layer.objects.active = obj
                try:
                    bpy.ops.object.location_clear()
                    bpy.ops.object.rotation_clear() 
                    bpy.ops.object.scale_clear()
                    success_count += 1
                except Exception as e:
                    print(f"Failed to clear transforms for {obj.name}: {e}")
            
            if success_count > 0:
                self.report({'INFO'}, f"Cleared transforms for {success_count} object(s)")
                return {'FINISHED'}
            else:
                self.report({'ERROR'}, "Failed to clear transforms")
                return {'CANCELLED'}
                
        except Exception as e:
            self.report({'ERROR'}, f"Failed to clear all transforms: {e}")
            return {'CANCELLED'}


class PIE_OT_ClearOrigin(Operator):
    bl_idname = "object.origin_clear"
    bl_label = "Clear Origin"
    bl_description = "Reset object origin to world center"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        try:

            if hasattr(bpy.ops.object, 'origin_clear'):
                bpy.ops.object.origin_clear()
            else:

                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            
            self.report({'INFO'}, "Origin cleared")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to clear origin: {e}")
            return {'CANCELLED'}

classes = (
    PIE_MT_PieApplyTransforms,
    PIE_MT_ClearMenu,
    PIE_OT_ClearAll,
    PIE_OT_ClearOrigin,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Object Mode')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'A', 'PRESS', ctrl=True)
            kmi.properties.name = "PIE_MT_applytransforms"
            addon_keymaps.append((km, kmi))
            
        print("pie_apply_transform_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_apply_transform_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_apply_transform_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_apply_transform_menu: {e}")

if __name__ == "__main__":
    register()
