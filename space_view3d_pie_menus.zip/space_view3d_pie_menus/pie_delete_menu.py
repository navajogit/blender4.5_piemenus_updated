

bl_info = {
    "name": "Hotkey: 'X'",
    "description": "Edit mode V/E/F Delete Modes",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "Mesh Edit Mode",
    "warning": "",
    "doc_url": "",
    "category": "Edit Delete Pie"
}

import bpy
from bpy.types import Menu


class PIE_MT_PieDelete(Menu):
    bl_idname = "PIE_MT_delete"
    bl_label = "Pie Delete"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        box = pie.split().column()
        box.label(text="Dissolve", icon='STICKY_UVS_LOC')
        box.operator("mesh.dissolve_limited", text="Limited Dissolve", icon='STICKY_UVS_LOC')
        

        if hasattr(bpy.ops.mesh, 'delete_edgeloop'):
            box.operator("mesh.delete_edgeloop", text="Delete Edge Loops", icon='EDGESEL')
        else:

            op = box.operator("mesh.delete", text="Delete Edge Loops", icon='EDGESEL')
            op.type = 'EDGE'
        
        box.operator("mesh.edge_collapse", text="Edge Collapse", icon='UV_EDGESEL')
        

        box = pie.split().column()
        box.label(text="Merge & Clean", icon='AUTOMERGE_OFF')
        

        if hasattr(bpy.ops.mesh, 'merge_by_distance'):
            box.operator("mesh.merge_by_distance", text="Merge By Distance", icon='AUTOMERGE_OFF')
        elif hasattr(bpy.ops.mesh, 'remove_doubles'):
            box.operator("mesh.remove_doubles", text="Merge By Distance", icon='AUTOMERGE_OFF')
        else:

            box.operator("mesh.merge", text="Merge", icon='AUTOMERGE_OFF').type = 'CENTER'
        
        op = box.operator("mesh.delete", text="Only Edge & Faces", icon='MESH_DATA')
        op.type = 'EDGE_FACE'
        
        op = box.operator("mesh.delete", text="Only Faces", icon='UV_FACESEL')
        op.type = 'ONLY_FACE'
        

        pie.operator("mesh.dissolve_edges", text="Dissolve Edges", icon='SNAP_EDGE')
        

        op = pie.operator("mesh.delete", text="Delete Edges", icon='EDGESEL')
        op.type = 'EDGE'
        

        op = pie.operator("mesh.delete", text="Delete Vertices", icon='VERTEXSEL')
        op.type = 'VERT'
        

        op = pie.operator("mesh.delete", text="Delete Faces", icon='FACESEL')
        op.type = 'FACE'
        

        pie.operator("mesh.dissolve_verts", text="Dissolve Vertices", icon='SNAP_VERTEX')
        

        pie.operator("mesh.dissolve_faces", text="Dissolve Faces", icon='SNAP_FACE')


class PIE_OT_SmartDelete(Menu):
    """Submenu for advanced delete options"""
    bl_idname = "PIE_MT_smart_delete"
    bl_label = "Smart Delete"

    def draw(self, context):
        layout = self.layout
        

        layout.operator("mesh.delete", text="Delete Vertices").type = 'VERT'
        layout.operator("mesh.delete", text="Delete Edges").type = 'EDGE' 
        layout.operator("mesh.delete", text="Delete Faces").type = 'FACE'
        layout.separator()
        

        layout.operator("mesh.dissolve_verts", text="Dissolve Vertices")
        layout.operator("mesh.dissolve_edges", text="Dissolve Edges")
        layout.operator("mesh.dissolve_faces", text="Dissolve Faces")
        layout.separator()
        

        layout.operator("mesh.dissolve_limited", text="Limited Dissolve")
        

        if hasattr(bpy.ops.mesh, 'delete_edgeloop'):
            layout.operator("mesh.delete_edgeloop", text="Delete Edge Loops")

classes = (
    PIE_MT_PieDelete,
    PIE_OT_SmartDelete,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Mesh')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS')
            kmi.properties.name = "PIE_MT_delete"
            addon_keymaps.append((km, kmi))
            
        print("pie_delete_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_delete_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_delete_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_delete_menu: {e}")

if __name__ == "__main__":
    register()
