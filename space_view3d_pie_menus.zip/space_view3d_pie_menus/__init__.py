

import bpy
import importlib
from bpy.props import (
    BoolProperty,
    PointerProperty,
)
from bpy.types import (
    PropertyGroup,
    AddonPreferences,
)

bl_info = {
    "name": "3D Viewport Pie Menus",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (2, 0, 0),
    "blender": (4, 5, 0),
    "description": "Pie Menu Activation for Blender 4.5+",
    "location": "Addons Preferences",
    "warning": "Updated for Blender 4.5 - some features may need adjustment",
    "doc_url": "https://docs.blender.org/manual/en/latest/addons/interface/viewport_pies.html",
    "category": "Interface",
    "support": "COMMUNITY"
}

sub_modules_names = (
    "pie_modes_menu",
    "pie_views_numpad_menu", 
    "pie_sculpt_menu",
    "pie_origin",
    "pie_manipulator_menu",
    "pie_shading_menu",
    "pie_align_menu",
    "pie_delete_menu",
    "pie_apply_transform_menu",
    "pie_select_menu",
    "pie_animation_menu",
    "pie_save_open_menu",
    "pie_editor_switch_menu",
    "pie_defaults_menu",
    "pie_proportional_menu",
)


sub_modules = []
failed_modules = []

def safe_import_modules():
    """Bezpiecznie importuje wszystkie moduły pie menu"""
    global sub_modules, failed_modules
    
    for submod_name in sub_modules_names:
        try:

            if __package__:
                module_name = f".{submod_name}"
                submod = importlib.import_module(module_name, __package__)
            else:
                submod = importlib.import_module(submod_name)
            

            if hasattr(submod, 'bl_info') and hasattr(submod, 'register'):
                sub_modules.append(submod)
                print(f"✓ Successfully loaded: {submod_name}")
            else:
                print(f"⚠ Module {submod_name} missing required attributes")
                failed_modules.append(submod_name)
                
        except ImportError as e:
            print(f"✗ Failed to import {submod_name}: {e}")
            failed_modules.append(submod_name)
        except Exception as e:
            print(f"✗ Unexpected error importing {submod_name}: {e}")
            failed_modules.append(submod_name)


safe_import_modules()


if sub_modules:
    try:
        sub_modules.sort(key=lambda mod: (mod.bl_info.get('category', ''), mod.bl_info.get('name', '')))
    except Exception as e:
        print(f"Warning: Could not sort modules: {e}")

def _get_pref_class(mod):
    """Znajduje klasę preferencji w module"""
    import inspect
    
    try:
        for obj in vars(mod).values():
            if (inspect.isclass(obj) and 
                issubclass(obj, PropertyGroup) and 
                hasattr(obj, 'bl_idname') and 
                obj.bl_idname == mod.__name__):
                return obj
    except Exception as e:
        print(f"Error getting preference class for {mod.__name__}: {e}")
    return None

def get_addon_preferences(name=''):
    """Pobiera preferencje addonu z lepszą obsługą błędów"""
    try:
        addons = bpy.context.preferences.addons
        if __name__ not in addons:
            return None
            
        addon_prefs = addons[__name__].preferences
        
        if name:
            if not hasattr(addon_prefs, name):
                for mod in sub_modules:
                    if mod.__name__.split('.')[-1] == name:
                        cls = _get_pref_class(mod)
                        if cls:
                            prop = PointerProperty(type=cls)
                            create_property(PIEToolsPreferences, name, prop)
                            try:
                                bpy.utils.unregister_class(PIEToolsPreferences)
                                bpy.utils.register_class(PIEToolsPreferences)
                            except RuntimeError:
                                pass
            return getattr(addon_prefs, name, None)
        else:
            return addon_prefs
    except Exception as e:
        print(f"Error getting addon preferences: {e}")
        return None

def create_property(cls, name, prop):
    """Tworzy właściwość w klasie"""
    if not hasattr(cls, '__annotations__'):
        cls.__annotations__ = {}
    cls.__annotations__[name] = prop

def register_submodule(mod):
    """Rejestruje pojedynczy moduł z obsługą błędów"""
    try:
        if hasattr(mod, 'register'):
            mod.register()
            mod.__addon_enabled__ = True
            print(f"✓ Registered: {mod.__name__}")
        else:
            print(f"✗ Module {mod.__name__} has no register function")
            mod.__addon_enabled__ = False
    except Exception as e:
        print(f"✗ Failed to register {mod.__name__}: {e}")
        mod.__addon_enabled__ = False

def unregister_submodule(mod):
    """Wyrejestrowuje pojedynczy moduł z obsługą błędów"""
    try:
        if hasattr(mod, '__addon_enabled__') and mod.__addon_enabled__:
            if hasattr(mod, 'unregister'):
                mod.unregister()
                print(f"✓ Unregistered: {mod.__name__}")
            mod.__addon_enabled__ = False
            

            prefs = get_addon_preferences()
            name = mod.__name__.split('.')[-1]
            if hasattr(PIEToolsPreferences, name):
                try:
                    delattr(PIEToolsPreferences, name)
                    if prefs:
                        bpy.utils.unregister_class(PIEToolsPreferences)
                        bpy.utils.register_class(PIEToolsPreferences)
                        if hasattr(prefs, name):
                            delattr(prefs, name)
                except Exception as inner_e:
                    print(f"Warning: Cleanup error for {name}: {inner_e}")
    except Exception as e:
        print(f"Error unregistering {mod.__name__}: {e}")

class PIEToolsPreferences(AddonPreferences):
    bl_idname = __name__

    def draw(self, context):
        layout = self.layout
        

        if failed_modules:
            box = layout.box()
            box.alert = True
            box.label(text="⚠ Some modules failed to load:", icon='ERROR')
            col = box.column()
            for failed in failed_modules:
                col.label(text=f"  • {failed}")
            col.separator()
            col.label(text="These modules may need to be updated for Blender 4.5")
            layout.separator()


        for mod in sub_modules:
            try:
                mod_name = mod.__name__.split('.')[-1]
                info = mod.bl_info
                column = layout.column()
                box = column.box()


                expand = getattr(self, f'show_expanded_{mod_name}', False)
                icon = 'TRIA_DOWN' if expand else 'TRIA_RIGHT'
                col = box.column()
                row = col.row()
                sub = row.row()
                sub.context_pointer_set('addon_prefs', self)
                
                op = sub.operator('wm.context_toggle', text='', icon=icon, emboss=False)
                op.data_path = f'addon_prefs.show_expanded_{mod_name}'
                
                sub.label(text=f"{info.get('category', 'Unknown')}: {info.get('name', mod_name)}")
                sub = row.row()
                sub.alignment = 'RIGHT'
                
                if info.get('warning'):
                    sub.label(text='', icon='ERROR')
                sub.prop(self, f'use_{mod_name}', text='')


                if expand:
                    if info.get('description'):
                        split = col.row().split(factor=0.15)
                        split.label(text='Description:')
                        split.label(text=info['description'])
                    
                    if info.get('location'):
                        split = col.row().split(factor=0.15)
                        split.label(text='Location:')
                        split.label(text=info['location'])
                    
                    if info.get('version'):
                        split = col.row().split(factor=0.15)
                        split.label(text='Version:')
                        split.label(text='.'.join(str(x) for x in info['version']), translate=False)
                    
                    if info.get('warning'):
                        split = col.row().split(factor=0.15)
                        split.label(text='Warning:')
                        split.label(text=f"  {info['warning']}", icon='ERROR')


                    if info.get('doc_url'):
                        split = col.row().split(factor=0.15)
                        split.label(text='Documentation:')
                        op = split.operator('wm.url_open', text='Open Documentation', icon='HELP')
                        op.url = info.get('doc_url')


                    if getattr(self, f'use_{mod_name}', False):
                        prefs = get_addon_preferences(mod_name)
                        if prefs and hasattr(prefs, 'draw'):
                            box_inner = box.column()
                            prefs.layout = box_inner
                            try:
                                prefs.draw(context)
                            except Exception as draw_error:
                                import traceback
                                traceback.print_exc()
                                box_inner.label(text=f'Error drawing preferences: {draw_error}', icon='ERROR')
                            finally:
                                if hasattr(prefs, 'layout'):
                                    delattr(prefs, 'layout')
                                    
            except Exception as e:
                print(f"Error drawing interface for {mod.__name__}: {e}")
                box.label(text=f"Error displaying {mod.__name__}", icon='ERROR')


        row = layout.row()
        row.label(text="End of Pie Menu Activations", icon="CHECKMARK")


for mod in sub_modules:
    try:
        info = mod.bl_info
        mod_name = mod.__name__.split('.')[-1]

        def gen_update(module):
            def update(self, context):
                enabled = getattr(self, f'use_{module.__name__.split(".")[-1]}', False)
                if enabled:
                    register_submodule(module)
                else:
                    unregister_submodule(module)
                setattr(module, '__addon_enabled__', enabled)
            return update


        create_property(
            PIEToolsPreferences,
            f'use_{mod_name}',
            BoolProperty(
                name=info.get('name', mod_name),
                description=info.get('description', f'Enable {mod_name}'),
                update=gen_update(mod),
                default=True,
            )
        )


        create_property(
            PIEToolsPreferences,
            f'show_expanded_{mod_name}',
            BoolProperty(
                name=f"Show {mod_name} details",
                description=f"Show detailed information for {mod_name}",
                default=False
            )
        )
        
    except Exception as e:
        print(f"Error creating properties for {mod.__name__}: {e}")

classes = (
    PIEToolsPreferences,
)

def register():
    """Rejestruje addon z pełną obsługą błędów"""
    print("Registering 3D Viewport Pie Menus for Blender 4.5...")
    print(f"Successfully loaded {len(sub_modules)} out of {len(sub_modules_names)} modules")
    
    if failed_modules:
        print(f"Failed to load: {', '.join(failed_modules)}")
    

    for cls in classes:
        try:
            bpy.utils.register_class(cls)
            print(f"✓ Registered class: {cls.__name__}")
        except Exception as e:
            print(f"✗ Failed to register class {cls.__name__}: {e}")


    try:
        prefs = get_addon_preferences()
        for mod in sub_modules:
            if not hasattr(mod, '__addon_enabled__'):
                mod.__addon_enabled__ = False
            
            mod_name = mod.__name__.split('.')[-1]
            should_enable = True
            
            if prefs:
                should_enable = getattr(prefs, f'use_{mod_name}', True)
            
            if should_enable:
                register_submodule(mod)
                
    except Exception as e:
        print(f"Error during module registration: {e}")
    
    print("Registration complete!")

def unregister():
    """Wyrejestrowuje addon z pełną obsługą błędów"""
    print("Unregistering 3D Viewport Pie Menus...")
    

    for mod in sub_modules:
        if hasattr(mod, '__addon_enabled__') and mod.__addon_enabled__:
            unregister_submodule(mod)


    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
            print(f"✓ Unregistered class: {cls.__name__}")
        except Exception as e:
            print(f"✗ Failed to unregister class {cls.__name__}: {e}")
    
    print("Unregistration complete!")

if __name__ == "__main__":
    register()
