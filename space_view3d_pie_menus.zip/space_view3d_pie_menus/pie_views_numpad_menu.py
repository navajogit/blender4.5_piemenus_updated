

bl_info = {
    "name": "Hotkey: 'Alt Q'",
    "description": "Viewport Numpad Menus",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "Alt Q key",
    "warning": "",
    "doc_url": "",
    "category": "View Numpad Pie"
}

import bpy
from bpy.types import (
    Menu,
    Operator,
)


class PIE_OT_LockTransforms(Operator):
    bl_idname = "object.locktransforms"
    bl_label = "Toggle Transform Locks"
    bl_description = ("Toggle object transform locks (rotation and scale)\n"
                     "Prevents accidental transformation of objects")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        try:
            obj = context.active_object
            

            currently_locked = any([obj.lock_rotation[i] for i in range(3)])
            
            if not currently_locked:

                for i in range(3):
                    obj.lock_rotation[i] = True
                    obj.lock_scale[i] = True
                self.report({'INFO'}, f"Locked transforms for {obj.name}")
            else:

                for i in range(3):
                    obj.lock_rotation[i] = False
                    obj.lock_scale[i] = False
                self.report({'INFO'}, f"Unlocked transforms for {obj.name}")

            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to toggle transform locks: {e}")
            return {'CANCELLED'}


class PIE_OT_ToggleViewportShading(Operator):
    bl_idname = "view3d.toggle_shading"
    bl_label = "Cycle Viewport Shading"
    bl_description = "Cycle through viewport shading modes"
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:
            shading = context.space_data.shading
            current_type = shading.type
            

            shading_cycle = ['WIREFRAME', 'SOLID', 'MATERIAL', 'RENDERED']
            current_index = shading_cycle.index(current_type) if current_type in shading_cycle else 0
            next_index = (current_index + 1) % len(shading_cycle)
            
            shading.type = shading_cycle[next_index]
            self.report({'INFO'}, f"Viewport shading: {shading_cycle[next_index].title()}")
            
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to cycle shading: {e}")
            return {'CANCELLED'}


class PIE_MT_ViewNumpad(Menu):
    bl_idname = "PIE_MT_viewnumpad"
    bl_label = "Viewport Views"

    def draw(self, context):
        layout = self.layout
        ob = context.active_object
        pie = layout.menu_pie()
        scene = context.scene
        rd = scene.render


        pie.operator("view3d.view_axis", text="Left View", icon='TRIA_LEFT').type = 'LEFT'
        

        pie.operator("view3d.view_axis", text="Right View", icon='TRIA_RIGHT').type = 'RIGHT'
        

        pie.operator("view3d.view_axis", text="Bottom View", icon='TRIA_DOWN').type = 'BOTTOM'
        

        pie.operator("view3d.view_axis", text="Top View", icon='TRIA_UP').type = 'TOP'
        

        pie.operator("view3d.view_axis", text="Back View", icon='AXIS_SIDE').type = 'BACK'
        

        pie.operator("view3d.view_axis", text="Front View", icon='AXIS_FRONT').type = 'FRONT'
        

        box = pie.split().column()
        box.label(text="Camera Controls", icon='CAMERA_DATA')
        
        row = box.row(align=True)
        row.operator("view3d.view_camera", text="View Camera", icon='HIDE_OFF')
        row.operator("view3d.camera_to_view", text="Camera to View", icon='VIEW_CAMERA')

        row = box.row(align=True)
        if context.space_data.lock_camera:
            row.operator("wm.context_toggle", text="Unlock Camera",
                         icon='LOCKED').data_path = "space_data.lock_camera"
        else:
            row.operator("wm.context_toggle", text="Lock Camera to View",
                         icon='UNLOCKED').data_path = "space_data.lock_camera"


        if ob:
            is_locked = any([ob.lock_rotation[i] for i in range(3)])
            icon_locked = 'LOCKED' if is_locked else 'UNLOCKED'
            row = box.row(align=True)
            row.operator("object.locktransforms", text="Transform Locks", icon=icon_locked)


        row = box.row(align=True)
        row.prop(rd, "use_border", text="Render Border", icon='BORDER_RECT')
        

        box = pie.split().column()
        box.label(text="View Controls", icon='VIEW3D')

        row = box.row(align=True)
        row.operator("view3d.view_all", text="Frame All", icon='VIEWZOOM').center = True
        row.operator("view3d.view_selected", text="Frame Selected", icon='ZOOM_SELECTED')

        row = box.row(align=True)

        is_persp = context.space_data.region_3d.is_perspective
        persp_text = "Orthographic" if is_persp else "Perspective"
        persp_icon = 'VIEW_ORTHO' if is_persp else 'VIEW_PERSPECTIVE'
        row.operator("view3d.view_persportho", text=persp_text, icon=persp_icon)
        

        is_local = context.space_data.local_view is not None
        local_text = "Global View" if is_local else "Local View"
        local_icon = 'RESTRICT_VIEW_ON' if is_local else 'RESTRICT_VIEW_OFF'
        row.operator("view3d.localview", text=local_text, icon=local_icon)

        row = box.row(align=True)

        if hasattr(context.screen, 'areas'):
            row.operator("screen.region_quadview", text="Toggle Quad View", icon='VIEW3D')
        

        row.operator("screen.screen_full_area", text="Toggle Fullscreen", icon='FULLSCREEN_ENTER')
        

        row = box.row(align=True)
        row.operator("view3d.toggle_shading", text="Cycle Shading", icon='SHADING_RENDERED')


class PIE_OT_SmartViewSelected(Operator):
    bl_idname = "view3d.smart_view_selected"
    bl_label = "Smart View Selected"
    bl_description = "Frame selected objects or all objects if none selected"
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:
            selected_objects = context.selected_objects
            
            if selected_objects:
                bpy.ops.view3d.view_selected()
                self.report({'INFO'}, f"Framed {len(selected_objects)} selected object(s)")
            else:
                bpy.ops.view3d.view_all(center=True)
                self.report({'INFO'}, "Framed all objects (none selected)")
            
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to frame view: {e}")
            return {'CANCELLED'}


class PIE_MT_ViewNumpadEnhanced(Menu):
    bl_idname = "PIE_MT_viewnumpad_enhanced"
    bl_label = "Enhanced Viewport Views"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()


        pie.operator("view3d.view_axis", text="Left", icon='TRIA_LEFT').type = 'LEFT'
        

        pie.operator("view3d.view_axis", text="Right", icon='TRIA_RIGHT').type = 'RIGHT'
        

        pie.menu("PIE_MT_view_more", text="More Views", icon='VIEW3D')
        

        pie.operator("view3d.view_axis", text="Top", icon='TRIA_UP').type = 'TOP'
        

        pie.operator("view3d.view_axis", text="Back", icon='AXIS_SIDE').type = 'BACK'
        

        pie.operator("view3d.view_axis", text="Front", icon='AXIS_FRONT').type = 'FRONT'
        

        pie.operator("view3d.view_camera", text="Camera View", icon='CAMERA_DATA')
        

        pie.operator("view3d.smart_view_selected", text="Frame Objects", icon='ZOOM_SELECTED')


class PIE_MT_ViewMore(Menu):
    bl_idname = "PIE_MT_view_more"
    bl_label = "More Viewport Options"

    def draw(self, context):
        layout = self.layout
        
        layout.label(text="Standard Views", icon='VIEW3D')
        layout.operator("view3d.view_axis", text="Bottom View").type = 'BOTTOM'
        
        layout.separator()
        
        layout.label(text="View Controls", icon='VIEWZOOM')
        layout.operator("view3d.view_all", text="Frame All").center = True
        layout.operator("view3d.view_selected", text="Frame Selected")
        layout.operator("view3d.view_persportho", text="Perspective/Orthographic")
        layout.operator("view3d.localview", text="Local/Global View")
        
        layout.separator()
        
        layout.label(text="Layout", icon='WORKSPACE')
        layout.operator("screen.region_quadview", text="Quad View")
        layout.operator("screen.screen_full_area", text="Fullscreen")

classes = (
    PIE_MT_ViewNumpad,
    PIE_MT_ViewNumpadEnhanced,
    PIE_MT_ViewMore,
    PIE_OT_LockTransforms,
    PIE_OT_ToggleViewportShading,
    PIE_OT_SmartViewSelected,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='3D View Generic', space_type='VIEW_3D')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'Q', 'PRESS', alt=True)
            kmi.properties.name = "PIE_MT_viewnumpad"
            addon_keymaps.append((km, kmi))
            

            km = wm.keyconfigs.addon.keymaps.new(name='3D View Generic', space_type='VIEW_3D')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'Q', 'PRESS', shift=True, alt=True)
            kmi.properties.name = "PIE_MT_viewnumpad_enhanced"
            addon_keymaps.append((km, kmi))
            
        print("pie_views_numpad_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_views_numpad_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_views_numpad_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_views_numpad_menu: {e}")

if __name__ == "__main__":
    register()
