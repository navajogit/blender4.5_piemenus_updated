

bl_info = {
    "name": "Hotkey: 'Ctrl U'",
    "description": "Save/Open & File Menus",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "All Editors",
    "warning": "",
    "doc_url": "",
    "category": "Interface"
}

import bpy
from bpy.types import (
    Menu,
    Operator,
)
import os


class PIE_MT_Load_Defaults(Menu):
    bl_idname = "PIE_MT_loaddefaults"
    bl_label = "Save/Open & Defaults"

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences
        pie = layout.menu_pie()
        

        pie.operator("wm.read_factory_settings", text="Load Factory Settings", icon='IMPORT')
        

        if hasattr(bpy.ops.wm, 'read_factory_userpref'):
            pie.operator("wm.read_factory_userpref", text="Load Factory Preferences", icon='RECOVER_LAST')
        else:

            pie.operator("wm.read_factory_settings", text="Reset Preferences", icon='RECOVER_LAST')
        

        pie.operator("wm.read_userpref", text="Revert to Saved Prefs", icon='FILE_REFRESH')
        

        pie.operator("wm.save_homefile", text="Save Startup File", icon='FILE_NEW')
        

        pie.prop(prefs, "use_preferences_save", text="Auto-Save Preferences", icon='LINK_BLEND')
        

        pie.operator("wm.save_userpref", text="Save User Preferences", icon='PREFERENCES')
        

        box = pie.split().box().column()
        box.label(text="File Operations", icon='FILE_FOLDER')
        box.operator("wm.open_mainfile", text="Open File", icon='FILE_FOLDER')
        box.operator("wm.save_mainfile", text="Save File", icon='FILE_TICK')
        box.operator("wm.save_as_mainfile", text="Save As...", icon='EXPORT')
        

        box = pie.split().box().column()
        box.label(text="Quick Access", icon='TIME')
        

        if hasattr(bpy.ops.wm, 'call_menu'):
            try:
                box.operator("wm.call_menu", text="Recent Files", icon='RECENT').name = "TOPBAR_MT_file_open_recent"
            except:
                box.operator("file.open_recent", text="Recent Files", icon='RECENT')
        

        box.separator()
        box.operator("wm.read_homefile", text="New File", icon='FILE_NEW')
        

        if hasattr(bpy.types, 'TOPBAR_MT_app_template'):
            try:
                box.operator("wm.call_menu", text="Templates", icon='PRESET').name = "TOPBAR_MT_app_template"  
            except:
                pass


class PIE_OT_OpenRecent(Operator):
    bl_idname = "file.open_recent"
    bl_label = "Open Recent File"
    bl_description = "Open the most recent file"
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:

            recent_files = bpy.utils.preset_paths("recent-files.txt")
            if recent_files:
                recent_file_path = recent_files[0]
                if os.path.exists(recent_file_path):
                    bpy.ops.wm.open_mainfile(filepath=recent_file_path)
                    self.report({'INFO'}, f"Opened: {os.path.basename(recent_file_path)}")
                    return {'FINISHED'}
            

            try:
                bpy.ops.wm.call_menu(name="TOPBAR_MT_file_open_recent")
                return {'FINISHED'}
            except:
                pass
                
            self.report({'WARNING'}, "No recent files found")
            return {'CANCELLED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to open recent file: {e}")
            return {'CANCELLED'}


class PIE_OT_SaveWithBackup(Operator):
    bl_idname = "file.save_with_backup"
    bl_label = "Save with Backup"
    bl_description = "Save file and create backup"
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:

            if bpy.data.is_saved:
                bpy.ops.wm.save_mainfile()
                self.report({'INFO'}, "File saved successfully")
            else:

                bpy.ops.wm.save_as_mainfile('INVOKE_DEFAULT')
                
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save file: {e}")
            return {'CANCELLED'}

classes = (
    PIE_MT_Load_Defaults,
    PIE_OT_OpenRecent,
    PIE_OT_SaveWithBackup,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Window')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'U', 'PRESS', ctrl=True)
            kmi.properties.name = "PIE_MT_loaddefaults"
            addon_keymaps.append((km, kmi))
            
        print("pie_save_open_menu registered successfully")
        
    except Exception as e:
        print(f"✗rror registering pie_save_open_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_save_open_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_save_open_menu: {e}")

if __name__ == "__main__":
    register()
