

bl_info = {
    "name": "Hotkey: 'A'",
    "description": "Object/Edit mode Selection Menu",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost))",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "3D View",
    "warning": "",
    "doc_url": "",
    "category": "Select Pie"
}

import bpy
from bpy.types import (
    Menu,
    Operator
)


class PIE_MT_SelectionsMore(Menu):
    bl_idname = "PIE_MT_selections_more"
    bl_label = "More Selection Options"

    def draw(self, context):
        layout = self.layout
        
        layout.label(text="Advanced Selection", icon='RESTRICT_SELECT_OFF')
        layout.separator()
        

        layout.operator("object.select_random", text="Select Random", icon='QUESTION')
        layout.operator("object.select_linked", text="Select Linked", icon='LINKED')
        
        layout.separator()
        

        layout.operator("object.select_more", text="Select More", icon='ADD')
        layout.operator("object.select_less", text="Select Less", icon='REMOVE')
        
        layout.separator()
        

        layout.label(text="Hierarchy", icon='OUTLINER')
        
        props = layout.operator("object.select_hierarchy", text="Select Parent")
        props.extend = False
        props.direction = 'PARENT'

        props = layout.operator("object.select_hierarchy", text="Select Child")
        props.extend = False
        props.direction = 'CHILD'
        
        layout.separator()
        
        props = layout.operator("object.select_hierarchy", text="Extend to Parent")
        props.extend = True
        props.direction = 'PARENT'

        props = layout.operator("object.select_hierarchy", text="Extend to Child")
        props.extend = True
        props.direction = 'CHILD'


class PIE_MT_SelectionsOM(Menu):
    bl_idname = "PIE_MT_selections_om"
    bl_label = "Object Selection"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        pie.operator("object.select_grouped", text="Select Grouped", icon='GROUP')
        

        pie.operator("object.select_by_type", text="Select By Type", icon='OBJECT_DATA')
        

        pie.operator("object.select_all", text="Invert Selection", 
                    icon='ARROW_LEFTRIGHT').action = 'INVERT'
        

        pie.operator("object.select_all", text="Select All Toggle", 
                    icon='RESTRICT_SELECT_OFF').action = 'TOGGLE'
        

        pie.operator("view3d.select_circle", text="Circle Select", icon='MESH_CIRCLE')
        

        pie.operator("view3d.select_box", text="Box Select", icon='BORDERSEL')
        

        pie.operator("object.select_camera", text="Select Camera", icon='CAMERA_DATA')
        

        pie.menu("PIE_MT_selections_more", text="More Options", icon='PREFERENCES')


class PIE_MT_SelectionsEM(Menu):
    bl_idname = "PIE_MT_selections_em"
    bl_label = "Edit Selection"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        pie.operator("mesh.select_less", text="Select Less", icon='REMOVE')
        

        pie.operator("mesh.select_more", text="Select More", icon='ADD')
        

        pie.menu("PIE_MT_select_loop", text="Loop Selection", icon='MESH_DATA')
        

        pie.operator("mesh.select_all", text="Select All Toggle", 
                    icon='RESTRICT_SELECT_OFF').action = 'TOGGLE'
        

        pie.operator("view3d.select_circle", text="Circle Select", icon='MESH_CIRCLE')
        

        pie.operator("view3d.select_box", text="Box Select", icon='BORDERSEL')
        

        pie.operator("mesh.select_all", text="Invert Selection", 
                    icon='ARROW_LEFTRIGHT').action = 'INVERT'
        

        pie.menu("PIE_MT_select_modes", text="Selection Modes", icon='VERTEXSEL')


class PIE_MT_SelectModes(Menu):
    bl_idname = "PIE_MT_select_modes"
    bl_label = "Selection Modes"

    def draw(self, context):
        layout = self.layout
        
        layout.label(text="Selection Mode", icon='EDITMODE_HLT')
        layout.separator()
        
        layout.operator("class.vertex_select", text="Vertex Select", icon='VERTEXSEL')
        layout.operator("class.edge_select", text="Edge Select", icon='EDGESEL')
        layout.operator("class.face_select", text="Face Select", icon='FACESEL')
        layout.separator()
        layout.operator("class.multi_select", text="Multi Select (V+E+F)", icon='OBJECT_DATAMODE')


class PIE_MT_SelectLoop(Menu):
    bl_idname = "PIE_MT_select_loop"
    bl_label = "Loop Selection"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'
        
        layout.label(text="Loop Selection", icon='MESH_DATA')
        layout.separator()
        
        layout.operator("mesh.loop_multi_select", text="Select Edge Loop", 
                       icon='EDGESEL').ring = False
        layout.operator("mesh.loop_multi_select", text="Select Edge Ring", 
                       icon='MESH_CIRCLE').ring = True
        layout.operator("mesh.loop_to_region", text="Loop Inner Region", 
                       icon='FACESEL')
        
        layout.separator()
        

        if hasattr(bpy.ops.mesh, 'select_face_by_sides'):
            layout.operator("mesh.select_face_by_sides", text="Select by Sides")


class PIE_OT_VertexSelect(Operator):
    bl_idname = "class.vertex_select"
    bl_label = "Vertex Select Mode"
    bl_description = "Switch to vertex selection mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode != "EDIT":
                bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
            self.report({'INFO'}, "Switched to vertex select mode")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to switch to vertex mode: {e}")
            return {'CANCELLED'}

class PIE_OT_EdgeSelect(Operator):
    bl_idname = "class.edge_select"
    bl_label = "Edge Select Mode"
    bl_description = "Switch to edge selection mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode != "EDIT":
                bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
            self.report({'INFO'}, "Switched to edge select mode")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to switch to edge mode: {e}")
            return {'CANCELLED'}

class PIE_OT_FaceSelect(Operator):
    bl_idname = "class.face_select"
    bl_label = "Face Select Mode"
    bl_description = "Switch to face selection mode"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode != "EDIT":
                bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
            self.report({'INFO'}, "Switched to face select mode")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to switch to face mode: {e}")
            return {'CANCELLED'}


class PIE_OT_MultiSelect(Operator):
    bl_idname = "class.multi_select"
    bl_label = "Multi Selection Mode"
    bl_description = "Enable vertex, edge, and face selection simultaneously"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        try:
            if context.object.mode != "EDIT":
                bpy.ops.object.mode_set(mode="EDIT")
            

            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
            bpy.ops.mesh.select_mode(use_extend=True, use_expand=False, type='EDGE')
            bpy.ops.mesh.select_mode(use_extend=True, use_expand=False, type='FACE')
            
            self.report({'INFO'}, "Enabled multi-selection mode")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to enable multi-selection: {e}")
            return {'CANCELLED'}


class PIE_OT_SmartSelect(Operator):
    bl_idname = "select.smart_all"
    bl_label = "Smart Select All"
    bl_description = "Context-sensitive select all"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            if context.mode == 'OBJECT':
                bpy.ops.object.select_all(action='TOGGLE')
                count = len([obj for obj in context.scene.objects if obj.select_get()])
                self.report({'INFO'}, f"Selected {count} objects")
            elif context.mode == 'EDIT_MESH':
                bpy.ops.mesh.select_all(action='TOGGLE')
                self.report({'INFO'}, "Toggled mesh selection")
            else:

                bpy.ops.mesh.select_all(action='TOGGLE')
            
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Smart select failed: {e}")
            return {'CANCELLED'}

classes = (
    PIE_MT_SelectionsOM,
    PIE_MT_SelectionsEM,
    PIE_MT_SelectModes,
    PIE_MT_SelectionsMore,
    PIE_MT_SelectLoop,
    PIE_OT_VertexSelect,
    PIE_OT_EdgeSelect,
    PIE_OT_FaceSelect,
    PIE_OT_MultiSelect,
    PIE_OT_SmartSelect,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Object Mode')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'A', 'PRESS')
            kmi.properties.name = "PIE_MT_selections_om"
            addon_keymaps.append((km, kmi))


            km = wm.keyconfigs.addon.keymaps.new(name='Mesh')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'A', 'PRESS')
            kmi.properties.name = "PIE_MT_selections_em"
            addon_keymaps.append((km, kmi))
            

            km = wm.keyconfigs.addon.keymaps.new(name='3D View Generic', space_type='VIEW_3D')
            kmi = km.keymap_items.new('select.smart_all', 'A', 'PRESS', alt=True)
            addon_keymaps.append((km, kmi))
            
        print("pie_select_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_select_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_select_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_select_menu: {e}")

if __name__ == "__main__":
    register()
