

bl_info = {
    "name": "Hotkey: 'Shift O'",
    "description": "Proportional Object/Edit Tools",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "3D View Object & Edit modes",
    "warning": "",
    "doc_url": "",
    "category": "Proportional Edit Pie"
}

import bpy
from bpy.types import (
    Menu,
    Operator,
)


class ProportionalEditOperatorBase(Operator):
    """Base class for proportional edit operators with common functionality"""
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.active_object is not None
    
    def get_tool_settings(self, context):
        """Get tool settings with error handling"""
        try:
            return context.tool_settings
        except Exception as e:
            self.report({'ERROR'}, f"Cannot access tool settings: {e}")
            return None


class PIE_OT_ProportionalEditObj(ProportionalEditOperatorBase):
    bl_idname = "proportional_obj.active"
    bl_label = "Toggle Proportional Edit Objects"
    bl_description = "Toggle proportional editing for objects"

    def execute(self, context):
        ts = self.get_tool_settings(context)
        if not ts:
            return {'CANCELLED'}
        
        try:
            ts.use_proportional_edit_objects = not ts.use_proportional_edit_objects
            status = "enabled" if ts.use_proportional_edit_objects else "disabled"
            self.report({'INFO'}, f"Proportional edit objects {status}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to toggle proportional edit: {e}")
            return {'CANCELLED'}

class PIE_OT_ProportionalFalloffObj(ProportionalEditOperatorBase):
    """Base class for object mode falloff operators"""
    falloff_type = 'SMOOTH'
    
    def execute(self, context):
        ts = self.get_tool_settings(context)
        if not ts:
            return {'CANCELLED'}
        
        try:

            if not ts.use_proportional_edit_objects:
                ts.use_proportional_edit_objects = True
            

            ts.proportional_edit_falloff = self.falloff_type
            self.report({'INFO'}, f"Set proportional falloff to {self.falloff_type.lower()}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set falloff: {e}")
            return {'CANCELLED'}

class PIE_OT_ProportionalSmoothObj(PIE_OT_ProportionalFalloffObj):
    bl_idname = "proportional_obj.smooth"
    bl_label = "Proportional Smooth Objects"
    bl_description = "Set proportional falloff to smooth"
    falloff_type = 'SMOOTH'

class PIE_OT_ProportionalSphereObj(PIE_OT_ProportionalFalloffObj):
    bl_idname = "proportional_obj.sphere"
    bl_label = "Proportional Sphere Objects"
    bl_description = "Set proportional falloff to sphere"
    falloff_type = 'SPHERE'

class PIE_OT_ProportionalRootObj(PIE_OT_ProportionalFalloffObj):
    bl_idname = "proportional_obj.root"
    bl_label = "Proportional Root Objects"
    bl_description = "Set proportional falloff to root"
    falloff_type = 'ROOT'

class PIE_OT_ProportionalSharpObj(PIE_OT_ProportionalFalloffObj):
    bl_idname = "proportional_obj.sharp"
    bl_label = "Proportional Sharp Objects"
    bl_description = "Set proportional falloff to sharp"
    falloff_type = 'SHARP'

class PIE_OT_ProportionalLinearObj(PIE_OT_ProportionalFalloffObj):
    bl_idname = "proportional_obj.linear"
    bl_label = "Proportional Linear Objects"
    bl_description = "Set proportional falloff to linear"
    falloff_type = 'LINEAR'

class PIE_OT_ProportionalConstantObj(PIE_OT_ProportionalFalloffObj):
    bl_idname = "proportional_obj.constant"
    bl_label = "Proportional Constant Objects"
    bl_description = "Set proportional falloff to constant"
    falloff_type = 'CONSTANT'

class PIE_OT_ProportionalRandomObj(PIE_OT_ProportionalFalloffObj):
    bl_idname = "proportional_obj.random"
    bl_label = "Proportional Random Objects"
    bl_description = "Set proportional falloff to random"
    falloff_type = 'RANDOM'

class PIE_OT_ProportionalInverseSquareObj(PIE_OT_ProportionalFalloffObj):
    bl_idname = "proportional_obj.inversesquare"
    bl_label = "Proportional Inverse Square Objects"
    bl_description = "Set proportional falloff to inverse square"
    falloff_type = 'INVERSE_SQUARE'


class PIE_OT_ProportionalEditEdt(ProportionalEditOperatorBase):
    bl_idname = "proportional_edt.active"
    bl_label = "Toggle Proportional Edit"
    bl_description = "Toggle proportional editing in edit mode"

    @classmethod
    def poll(cls, context):
        return (context.active_object and 
                context.active_object.type == 'MESH' and 
                context.mode == 'EDIT_MESH')

    def execute(self, context):
        ts = self.get_tool_settings(context)
        if not ts:
            return {'CANCELLED'}
        
        try:
            ts.use_proportional_edit = not ts.use_proportional_edit
            status = "enabled" if ts.use_proportional_edit else "disabled"
            self.report({'INFO'}, f"Proportional edit {status}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to toggle proportional edit: {e}")
            return {'CANCELLED'}

class PIE_OT_ProportionalConnectedEdt(ProportionalEditOperatorBase):
    bl_idname = "proportional_edt.connected"
    bl_label = "Toggle Proportional Connected"
    bl_description = "Toggle proportional connected editing"

    @classmethod
    def poll(cls, context):
        return (context.active_object and 
                context.active_object.type == 'MESH' and 
                context.mode == 'EDIT_MESH')

    def execute(self, context):
        ts = self.get_tool_settings(context)
        if not ts:
            return {'CANCELLED'}
        
        try:
            ts.use_proportional_connected = not ts.use_proportional_connected
            status = "enabled" if ts.use_proportional_connected else "disabled"
            self.report({'INFO'}, f"Proportional connected {status}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to toggle proportional connected: {e}")
            return {'CANCELLED'}

class PIE_OT_ProportionalProjectedEdt(ProportionalEditOperatorBase):
    bl_idname = "proportional_edt.projected"
    bl_label = "Toggle Proportional Projected"
    bl_description = "Toggle proportional projected editing"

    @classmethod
    def poll(cls, context):
        return (context.active_object and 
                context.active_object.type == 'MESH' and 
                context.mode == 'EDIT_MESH')

    def execute(self, context):
        ts = self.get_tool_settings(context)
        if not ts:
            return {'CANCELLED'}
        
        try:

            if hasattr(ts, 'use_proportional_projected'):
                ts.use_proportional_projected = not ts.use_proportional_projected
                status = "enabled" if ts.use_proportional_projected else "disabled"
                self.report({'INFO'}, f"Proportional projected {status}")
            else:
                self.report({'WARNING'}, "Proportional projected not available in this version")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to toggle proportional projected: {e}")
            return {'CANCELLED'}

class PIE_OT_ProportionalFalloffEdt(ProportionalEditOperatorBase):
    """Base class for edit mode falloff operators"""
    falloff_type = 'SMOOTH'
    
    @classmethod
    def poll(cls, context):
        return (context.active_object and 
                context.active_object.type == 'MESH' and 
                context.mode == 'EDIT_MESH')
    
    def execute(self, context):
        ts = self.get_tool_settings(context)
        if not ts:
            return {'CANCELLED'}
        
        try:

            if not ts.use_proportional_edit:
                ts.use_proportional_edit = True
            

            ts.proportional_edit_falloff = self.falloff_type
            self.report({'INFO'}, f"Set proportional falloff to {self.falloff_type.lower()}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to set falloff: {e}")
            return {'CANCELLED'}

class PIE_OT_ProportionalSmoothEdt(PIE_OT_ProportionalFalloffEdt):
    bl_idname = "proportional_edt.smooth"
    bl_label = "Proportional Smooth Edit"
    bl_description = "Set proportional falloff to smooth"
    falloff_type = 'SMOOTH'

class PIE_OT_ProportionalSphereEdt(PIE_OT_ProportionalFalloffEdt):
    bl_idname = "proportional_edt.sphere"
    bl_label = "Proportional Sphere Edit"
    bl_description = "Set proportional falloff to sphere"
    falloff_type = 'SPHERE'

class PIE_OT_ProportionalRootEdt(PIE_OT_ProportionalFalloffEdt):
    bl_idname = "proportional_edt.root"
    bl_label = "Proportional Root Edit"
    bl_description = "Set proportional falloff to root"
    falloff_type = 'ROOT'

class PIE_OT_ProportionalSharpEdt(PIE_OT_ProportionalFalloffEdt):
    bl_idname = "proportional_edt.sharp"
    bl_label = "Proportional Sharp Edit"
    bl_description = "Set proportional falloff to sharp"
    falloff_type = 'SHARP'

class PIE_OT_ProportionalLinearEdt(PIE_OT_ProportionalFalloffEdt):
    bl_idname = "proportional_edt.linear"
    bl_label = "Proportional Linear Edit"
    bl_description = "Set proportional falloff to linear"
    falloff_type = 'LINEAR'

class PIE_OT_ProportionalConstantEdt(PIE_OT_ProportionalFalloffEdt):
    bl_idname = "proportional_edt.constant"
    bl_label = "Proportional Constant Edit"
    bl_description = "Set proportional falloff to constant"
    falloff_type = 'CONSTANT'

class PIE_OT_ProportionalRandomEdt(PIE_OT_ProportionalFalloffEdt):
    bl_idname = "proportional_edt.random"
    bl_label = "Proportional Random Edit"
    bl_description = "Set proportional falloff to random"
    falloff_type = 'RANDOM'

class PIE_OT_ProportionalInverseSquareEdt(PIE_OT_ProportionalFalloffEdt):
    bl_idname = "proportional_edt.inversesquare"
    bl_label = "Proportional Inverse Square Edit"
    bl_description = "Set proportional falloff to inverse square"
    falloff_type = 'INVERSE_SQUARE'


class PIE_MT_ProportionalObj(Menu):
    bl_idname = "PIE_MT_proportional_obj"
    bl_label = "Proportional Objects"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        ts = context.tool_settings
        

        pie.operator("proportional_obj.smooth", text="Smooth", icon='SMOOTHCURVE')
        

        pie.operator("proportional_obj.sphere", text="Sphere", icon='SPHERECURVE')
        

        pie.operator("proportional_obj.linear", text="Linear", icon='LINCURVE')
        

        icon = 'PROP_ON' if ts.use_proportional_edit_objects else 'PROP_OFF'
        text = f"Proportional {'ON' if ts.use_proportional_edit_objects else 'OFF'}"
        pie.prop(ts, "use_proportional_edit_objects", text=text, icon=icon, toggle=True)
        

        pie.operator("proportional_obj.root", text="Root", icon='ROOTCURVE')
        

        pie.operator("proportional_obj.inversesquare", text="Inverse Square", icon='INVERSESQUARECURVE')
        

        pie.operator("proportional_obj.sharp", text="Sharp", icon='SHARPCURVE')
        

        pie.menu("PIE_MT_proportional_more_obj", text="More Options", icon='PREFERENCES')


class PIE_MT_ProportionalEdt(Menu):
    bl_idname = "PIE_MT_proportional_edt"
    bl_label = "Proportional Edit"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        ts = context.tool_settings
        

        pie.operator("proportional_edt.smooth", text="Smooth", icon='SMOOTHCURVE')
        

        pie.operator("proportional_edt.sphere", text="Sphere", icon='SPHERECURVE')
        

        pie.operator("proportional_edt.inversesquare", text="Inverse Square", icon='INVERSESQUARECURVE')
        

        icon = 'PROP_ON' if ts.use_proportional_edit else 'PROP_OFF'
        text = f"Proportional {'ON' if ts.use_proportional_edit else 'OFF'}"
        pie.operator("proportional_edt.active", text=text, icon=icon)
        

        icon = 'PROP_CON' if ts.use_proportional_connected else 'PROP_OFF'
        pie.operator("proportional_edt.connected", text="Connected", icon=icon)
        

        if hasattr(ts, 'use_proportional_projected'):
            icon = 'PROP_PROJECTED' if ts.use_proportional_projected else 'PROP_OFF'
            pie.operator("proportional_edt.projected", text="Projected", icon=icon)
        else:
            pie.separator()
        

        pie.operator("proportional_edt.root", text="Root", icon='ROOTCURVE')
        

        pie.menu("PIE_MT_proportional_more_edt", text="More Options", icon='PREFERENCES')


class PIE_MT_ProportionalMoreEdt(Menu):
    bl_idname = "PIE_MT_proportional_more_edt"
    bl_label = "Proportional Edit - More Options"

    def draw(self, context):
        layout = self.layout
        ts = context.tool_settings
        

        layout.label(text=f"Current: {ts.proportional_edit_falloff.title()}", icon='INFO')
        layout.separator()
        

        layout.operator("proportional_edt.sharp", text="Sharp", icon='SHARPCURVE')
        layout.operator("proportional_edt.linear", text="Linear", icon='LINCURVE')
        layout.operator("proportional_edt.constant", text="Constant", icon='NOCURVE')
        layout.operator("proportional_edt.random", text="Random", icon='RNDCURVE')
        
        layout.separator()
        

        layout.prop(ts, "proportional_size", text="Size")


class PIE_MT_ProportionalMoreObj(Menu):
    bl_idname = "PIE_MT_proportional_more_obj"
    bl_label = "Proportional Objects - More Options"

    def draw(self, context):
        layout = self.layout
        ts = context.tool_settings
        

        layout.label(text=f"Current: {ts.proportional_edit_falloff.title()}", icon='INFO')
        layout.separator()
        

        layout.operator("proportional_obj.constant", text="Constant", icon='NOCURVE')
        layout.operator("proportional_obj.random", text="Random", icon='RNDCURVE')
        
        layout.separator()
        

        layout.prop(ts, "proportional_size", text="Size")

classes = (
    PIE_OT_ProportionalEditObj,
    PIE_OT_ProportionalSmoothObj,
    PIE_OT_ProportionalSphereObj,
    PIE_OT_ProportionalRootObj,
    PIE_OT_ProportionalSharpObj,
    PIE_OT_ProportionalLinearObj,
    PIE_OT_ProportionalConstantObj,
    PIE_OT_ProportionalRandomObj,
    PIE_OT_ProportionalInverseSquareObj,
    PIE_OT_ProportionalEditEdt,
    PIE_OT_ProportionalConnectedEdt,
    PIE_OT_ProportionalProjectedEdt,
    PIE_OT_ProportionalSmoothEdt,
    PIE_OT_ProportionalSphereEdt,
    PIE_OT_ProportionalRootEdt,
    PIE_OT_ProportionalSharpEdt,
    PIE_OT_ProportionalLinearEdt,
    PIE_OT_ProportionalConstantEdt,
    PIE_OT_ProportionalRandomEdt,
    PIE_OT_ProportionalInverseSquareEdt,
    PIE_MT_ProportionalObj,
    PIE_MT_ProportionalEdt,
    PIE_MT_ProportionalMoreEdt,
    PIE_MT_ProportionalMoreObj,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Object Mode')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'O', 'PRESS', shift=True)
            kmi.properties.name = "PIE_MT_proportional_obj"
            addon_keymaps.append((km, kmi))


            km = wm.keyconfigs.addon.keymaps.new(name='Mesh')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'O', 'PRESS', shift=True)
            kmi.properties.name = "PIE_MT_proportional_edt"
            addon_keymaps.append((km, kmi))
            
        print("pie_proportional_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_proportional_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_proportional_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_proportional_menu: {e}")

if __name__ == "__main__":
    register()
