

bl_info = {
    "name": "Hotkey: 'Shift Spacebar'",
    "description": "Pie menu for Timeline controls",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "3D View",
    "warning": "",
    "doc_url": "",
    "category": "Animation Pie"
}

import bpy
from bpy.types import (
    Menu,
    Operator,
)


class PIE_MT_PieAnimation(Menu):
    bl_idname = "PIE_MT_pie_animation"
    bl_label = "Pie Animation"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        pie.operator("screen.frame_jump", text="Jump REW", icon='REW').end = False
        

        pie.operator("screen.frame_jump", text="Jump FF", icon='FF').end = True
        

        pie.operator("screen.animation_play", text="Reverse", icon='PLAY_REVERSE').reverse = True
        

        if not context.screen.is_animation_playing:
            pie.operator("screen.animation_play", text="Play", icon='PLAY')
        else:
            pie.operator("screen.animation_play", text="Stop", icon='PAUSE')
        

        pie.operator("screen.keyframe_jump", text="Previous FR", icon='PREV_KEYFRAME').next = False
        

        pie.operator("screen.keyframe_jump", text="Next FR", icon='NEXT_KEYFRAME').next = True
        

        pie.operator("insert.autokeyframe", text="Auto Keyframe", icon='REC')
        

        try:
            pie.menu("VIEW3D_MT_object_animation", text="Keyframe Menu", icon="KEYINGSET")
        except:

            pie.operator("anim.keyframe_insert_menu", text="Insert Keyframe", icon="KEYINGSET")


class PIE_OT_InsertAutoKeyframe(Operator):
    bl_idname = "insert.autokeyframe"
    bl_label = "Insert Auto Keyframe"
    bl_description = "Toggle Insert Auto Keyframe"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            ts = context.tool_settings
            ts.use_keyframe_insert_auto = not ts.use_keyframe_insert_auto
            

            for area in context.screen.areas:
                if area.type == 'TIMELINE':
                    area.tag_redraw()
            

            status = "ON" if ts.use_keyframe_insert_auto else "OFF"
            self.report({'INFO'}, f"Auto Keyframe: {status}")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to toggle auto keyframe: {e}")
            return {'CANCELLED'}

classes = (
    PIE_MT_PieAnimation,
    PIE_OT_InsertAutoKeyframe
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Object Non-modal')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'SPACE', 'PRESS', shift=True)
            kmi.properties.name = "PIE_MT_pie_animation"
            addon_keymaps.append((km, kmi))
            
        print("✓ pie_animation_menu registered successfully")
        
    except Exception as e:
        print(f"✗ Error registering pie_animation_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("✓ pie_animation_menu unregistered successfully")
        
    except Exception as e:
        print(f"✗ Error unregistering pie_animation_menu: {e}")

if __name__ == "__main__":
    register()
