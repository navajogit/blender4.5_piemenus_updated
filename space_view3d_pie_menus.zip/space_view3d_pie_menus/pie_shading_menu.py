

bl_info = {
    "name": "Hotkey: 'Z'",
    "description": "Viewport Shading Menus",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "3D View",
    "warning": "",
    "doc_url": "",
    "category": "Shading Pie"
}

import bpy
from bpy.types import Menu


class PIE_MT_ShadingView(Menu):
    bl_idname = "PIE_MT_shadingview"
    bl_label = "Viewport Shading"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        pie.prop(context.space_data.shading, "type", expand=True)
        

        if context.active_object:
            if context.mode == 'EDIT_MESH':

                pie.operator("mesh.shade_smooth", text="Shade Smooth", icon='MESH_DATA')
                pie.operator("mesh.shade_flat", text="Shade Flat", icon='MESH_DATA')
            else:

                pie.operator("object.shade_smooth", text="Shade Smooth", icon='OBJECT_DATA')
                pie.operator("object.shade_flat", text="Shade Flat", icon='OBJECT_DATA')
        else:

            pie.separator()
            pie.separator()

classes = (
    PIE_MT_ShadingView,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='3D View Generic', space_type='VIEW_3D')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'Z', 'PRESS')
            kmi.properties.name = "PIE_MT_shadingview"
            addon_keymaps.append((km, kmi))
            
        print("pie_views_numpad_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_views_numpad_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_views_numpad_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_views_numpad_menu: {e}")

if __name__ == "__main__":
    register()
