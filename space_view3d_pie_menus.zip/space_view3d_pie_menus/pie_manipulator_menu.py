

bl_info = {
    "name": "Hotkey: 'Alt Spacebar'",
    "description": "Manipulator/Gizmo Menu",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "3D View",
    "warning": "",
    "doc_url": "",
    "category": "Manipulator Pie"
}

import bpy
from bpy.types import (
    Menu,
    Operator,
)
from bpy.props import (
    BoolProperty,
    EnumProperty,
)


class PIE_OT_WManipulators(Operator):
    bl_idname = "w.manipulators"
    bl_label = "Gizmo Toggle"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Show/Hide specific gizmo types"
    
    extend: BoolProperty(
        name="Extend",
        description="Extend selection instead of replacing",
        default=False,
    )
    
    type: EnumProperty(
        name="Gizmo Type",
        items=(
            ('TRANSLATE', "Move", "Move/Translate Gizmo"),
            ('ROTATE', "Rotate", "Rotate Gizmo"),
            ('SCALE', "Scale", "Scale Gizmo"),
        )
    )
    
    @classmethod
    def poll(cls, context):
        return (context.area and context.area.type == 'VIEW_3D' and 
                context.space_data)

    def execute(self, context):
        try:
            space_data = context.space_data
            

            space_data.show_gizmo = True
            

            gizmo_attrs = self._get_gizmo_attributes(space_data)
            
            if not gizmo_attrs:
                self.report({'ERROR'}, "Gizmo properties not found")
                return {'CANCELLED'}
            
            attr_t, attr_r, attr_s = gizmo_attrs
            attr_index = ('TRANSLATE', 'ROTATE', 'SCALE').index(self.type)
            attr_active = gizmo_attrs[attr_index]
            
            if self.extend:

                current_value = getattr(space_data, attr_active, False)
                setattr(space_data, attr_active, not current_value)
                status = "enabled" if not current_value else "disabled"
                self.report({'INFO'}, f"{self.type.title()} gizmo {status}")
            else:

                for attr in gizmo_attrs:
                    setattr(space_data, attr, attr == attr_active)
                self.report({'INFO'}, f"Showing only {self.type.lower()} gizmo")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to toggle gizmo: {e}")
            return {'CANCELLED'}
    
    def _get_gizmo_attributes(self, space_data):
        """Get the correct gizmo attribute names for the current Blender version"""

        new_attrs = (
            "show_gizmo_object_translate",
            "show_gizmo_object_rotate", 
            "show_gizmo_object_scale",
        )
        

        legacy_attrs = (
            "show_manipulator_translate",
            "show_manipulator_rotate",
            "show_manipulator_scale",
        )
        

        for attrs in [new_attrs, legacy_attrs]:
            if all(hasattr(space_data, attr) for attr in attrs):
                return attrs
        

        all_attrs = dir(space_data)
        gizmo_attrs = []
        
        for pattern in ['translate', 'rotate', 'scale']:
            found_attr = None
            for attr in all_attrs:
                if (pattern in attr.lower() and 
                    ('gizmo' in attr.lower() or 'manipulator' in attr.lower()) and
                    'show' in attr.lower()):
                    found_attr = attr
                    break
            if found_attr:
                gizmo_attrs.append(found_attr)
        
        return tuple(gizmo_attrs) if len(gizmo_attrs) == 3 else None
    
    def invoke(self, context, event):
        self.extend = event.shift
        return self.execute(context)


class PIE_MT_Manipulator(Menu):
    bl_idname = "PIE_MT_manipulator"
    bl_label = "Gizmo Control"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        pie.operator("w.manipulators", text="Rotate", icon='DRIVER_ROTATIONAL_DIFFERENCE').type = 'ROTATE'
        

        pie.operator("w.manipulators", text="Scale", icon='FULLSCREEN_EXIT').type = 'SCALE'
        

        if self._has_show_gizmo(context):
            props = pie.operator("wm.context_toggle", text="Show/Hide All Gizmos", icon='GIZMO')
            props.data_path = "space_data.show_gizmo"
        else:

            props = pie.operator("wm.context_toggle", text="Show/Hide All Gizmos", icon='GIZMO')
            props.data_path = "space_data.show_gizmo_context"
        

        pie.operator("w.manipulators", text="Translate", icon='ORIENTATION_GLOBAL').type = 'TRANSLATE'
        

        box = pie.split().box().column()
        box.label(text="Gizmo Options", icon='PREFERENCES')
        

        if hasattr(context.scene, 'transform_orientation_slots'):
            box.prop(context.scene.transform_orientation_slots[0], "type", text="")
        

        if hasattr(context.scene.tool_settings, 'transform_pivot_point'):
            box.prop(context.scene.tool_settings, "transform_pivot_point", text="")
        

        box = pie.split().box().column()
        box.label(text="Individual Gizmos", icon='RESTRICT_VIEW_OFF')
        
        space = context.space_data
        gizmo_attrs = self._get_gizmo_display_properties(space)
        
        if gizmo_attrs:
            for attr, label, icon in gizmo_attrs:
                if hasattr(space, attr):
                    box.prop(space, attr, text=label, icon=icon)
        

        pie.separator()
        

        box = pie.split().box().column()
        box.label(text="Tool Settings", icon='TOOL_SETTINGS')
        

        if hasattr(context.scene.tool_settings, 'use_proportional_edit'):
            box.prop(context.scene.tool_settings, "use_proportional_edit", text="Proportional")
        

        if hasattr(context.scene.tool_settings, 'use_snap'):
            box.prop(context.scene.tool_settings, "use_snap", text="Snap")
    
    def _has_show_gizmo(self, context):
        """Check if the space_data has show_gizmo property"""
        return hasattr(context.space_data, 'show_gizmo')
    
    def _get_gizmo_display_properties(self, space):
        """Get available gizmo display properties with labels and icons"""
        properties = []
        

        gizmo_mappings = [
            ('show_gizmo_object_translate', 'Translate', 'ORIENTATION_GLOBAL'),
            ('show_gizmo_object_rotate', 'Rotate', 'DRIVER_ROTATIONAL_DIFFERENCE'),
            ('show_gizmo_object_scale', 'Scale', 'FULLSCREEN_EXIT'),
            ('show_manipulator_translate', 'Translate', 'ORIENTATION_GLOBAL'),
            ('show_manipulator_rotate', 'Rotate', 'DRIVER_ROTATIONAL_DIFFERENCE'), 
            ('show_manipulator_scale', 'Scale', 'FULLSCREEN_EXIT'),
        ]
        
        for attr, label, icon in gizmo_mappings:
            if hasattr(space, attr):
                properties.append((attr, label, icon))
        

        seen = set()
        unique_properties = []
        for prop in properties:
            if prop[1] not in seen:
                seen.add(prop[1])
                unique_properties.append(prop)
        
        return unique_properties

classes = (
    PIE_OT_WManipulators,
    PIE_MT_Manipulator,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='3D View Generic', space_type='VIEW_3D')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'SPACE', 'PRESS', alt=True)
            kmi.properties.name = "PIE_MT_manipulator"
            addon_keymaps.append((km, kmi))
            
        print("pie_manipulator_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_manipulator_menu: {e}")

def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_manipulator_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_manipulator_menu: {e}")

if __name__ == "__main__":
    register()
