

bl_info = {
    "name": "Hotkey: 'Alt X'",
    "description": "V/E/F Align tools",
    "author": "pitiwazou, meta-androcto (updated for Blender 4.5 by cyberghost)",
    "version": (0, 2, 0),
    "blender": (4, 5, 0),
    "location": "Mesh Edit Mode",
    "warning": "",
    "doc_url": "",
    "category": "Edit Align Pie"
}

import bpy
import bmesh
from bpy.types import (
    Menu,
    Operator,
)
from bpy.props import EnumProperty


class PIE_MT_Align(Menu):
    bl_idname = "PIE_MT_align"
    bl_label = "Pie Align"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        

        box = pie.split().box().column()
        box.label(text="Align to Negative", icon='BACK')

        row = box.row(align=True)
        row.label(text="X")
        align_1 = row.operator("alignxyz.all", text="Neg")
        align_1.axis = '0'
        align_1.side = 'NEGATIVE'

        row = box.row(align=True)
        row.label(text="Y")
        align_3 = row.operator("alignxyz.all", text="Neg")
        align_3.axis = '1'
        align_3.side = 'NEGATIVE'

        row = box.row(align=True)
        row.label(text="Z")
        align_5 = row.operator("alignxyz.all", text="Neg")
        align_5.axis = '2'
        align_5.side = 'NEGATIVE'
        

        box = pie.split().box().column()
        box.label(text="Align to Positive", icon='FORWARD')

        row = box.row(align=True)
        row.label(text="X")
        align_2 = row.operator("alignxyz.all", text="Pos")
        align_2.axis = '0'
        align_2.side = 'POSITIVE'

        row = box.row(align=True)
        row.label(text="Y")
        align_4 = row.operator("alignxyz.all", text="Pos")
        align_4.axis = '1'
        align_4.side = 'POSITIVE'

        row = box.row(align=True)
        row.label(text="Z")
        align_6 = row.operator("alignxyz.all", text="Pos")
        align_6.axis = '2'
        align_6.side = 'POSITIVE'
        

        pie.operator("align.2xyz", text="Align To Y-0", icon='AXIS_SIDE').axis = '1'
        

        pie.operator("align.selected2xyz", text="Align Y", icon='AXIS_FRONT').axis = 'Y'
        

        pie.operator("align.selected2xyz", text="Align X", icon='AXIS_SIDE').axis = 'X'
        

        pie.operator("align.selected2xyz", text="Align Z", icon='AXIS_TOP').axis = 'Z'
        

        pie.operator("align.2xyz", text="Align To X-0", icon='AXIS_SIDE').axis = '0'
        

        pie.operator("align.2xyz", text="Align To Z-0", icon='AXIS_TOP').axis = '2'


class PIE_OT_AlignSelectedXYZ(Operator):
    bl_idname = "align.selected2xyz"
    bl_label = "Align to X, Y, Z"
    bl_description = "Align Selected Along the chosen axis"
    bl_options = {'REGISTER', 'UNDO'}

    axis: EnumProperty(
        name="Axis",
        items=[
            ('X', "X", "X Axis"),
            ('Y', "Y", "Y Axis"),
            ('Z', "Z", "Z Axis")
        ],
        description="Choose an axis for alignment",
        default='X'
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == "MESH" and 
                context.mode == 'EDIT_MESH')

    def execute(self, context):
        try:

            values = {
                'X': [(0, 1, 1), (True, False, False)],
                'Y': [(1, 0, 1), (False, True, False)],
                'Z': [(1, 1, 0), (False, False, True)]
            }
            
            chosen_value = values[self.axis][0]
            constraint_value = values[self.axis][1]
            

            bpy.ops.transform.resize(
                value=chosen_value,
                constraint_axis=constraint_value,
                orient_type='GLOBAL',
                mirror=False,
                use_proportional_edit=False,
            )
            
            self.report({'INFO'}, f"Aligned selection along {self.axis} axis")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to align: {e}")
            return {'CANCELLED'}


class PIE_OT_AlignToXYZ0(Operator):
    bl_idname = "align.2xyz"
    bl_label = "Align To X, Y or Z = 0"
    bl_description = "Align Active Object To a chosen X, Y or Z equals 0 Location"
    bl_options = {'REGISTER', 'UNDO'}

    axis: EnumProperty(
        name="Axis",
        items=[
            ('0', "X", "X Axis"),
            ('1', "Y", "Y Axis"),
            ('2', "Z", "Z Axis")
        ],
        description="Choose an axis for alignment",
        default='0'
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == "MESH" and 
                context.mode == 'EDIT_MESH')

    def execute(self, context):
        try:
            obj = context.active_object
            mesh = obj.data
            bm = bmesh.from_mesh(mesh)
            

            bm.faces.ensure_lookup_table()
            bm.verts.ensure_lookup_table()
            
            axis_index = int(self.axis)
            selected_verts = [v for v in bm.verts if v.select]
            
            if not selected_verts:
                self.report({'WARNING'}, "No vertices selected")
                bm.free()
                return {'CANCELLED'}
            

            for vert in selected_verts:
                vert.co[axis_index] = 0.0
            

            bmesh.update_edit_mesh(mesh)
            bm.free()
            
            axis_names = ['X', 'Y', 'Z']
            self.report({'INFO'}, f"Aligned to {axis_names[axis_index]}=0")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to align to 0: {e}")
            return {'CANCELLED'}


class PIE_OT_AlignXYZAll(Operator):
    bl_idname = "alignxyz.all"
    bl_label = "Align to Front/Back Axis"
    bl_description = "Align to a Front or Back along the chosen Axis"
    bl_options = {'REGISTER', 'UNDO'}

    axis: EnumProperty(
        name="Axis",
        items=[
            ('0', "X", "X Axis"),
            ('1', "Y", "Y Axis"),
            ('2', "Z", "Z Axis")
        ],
        description="Choose an axis for alignment",
        default='0'
    )
    
    side: EnumProperty(
        name="Side",
        items=[
            ('POSITIVE', "Front", "Align on the positive chosen axis"),
            ('NEGATIVE', "Back", "Align across the negative chosen axis"),
        ],
        description="Choose a side for alignment",
        default='POSITIVE'
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == "MESH" and 
                context.mode == 'EDIT_MESH')

    def execute(self, context):
        try:
            obj = context.active_object
            mesh = obj.data
            bm = bmesh.from_mesh(mesh)
            

            bm.verts.ensure_lookup_table()
            
            axis_index = int(self.axis)
            selected_verts = [v for v in bm.verts if v.select]
            
            if not selected_verts:
                self.report({'WARNING'}, "No vertices selected")
                bm.free()
                return {'CANCELLED'}
            

            target_value = selected_verts[0].co[axis_index]
            
            for vert in selected_verts[1:]:
                if self.side == 'POSITIVE':
                    if vert.co[axis_index] > target_value:
                        target_value = vert.co[axis_index]
                else:
                    if vert.co[axis_index] < target_value:
                        target_value = vert.co[axis_index]
            

            for vert in selected_verts:
                vert.co[axis_index] = target_value
            

            bmesh.update_edit_mesh(mesh)
            bm.free()
            
            axis_names = ['X', 'Y', 'Z']
            side_name = "positive" if self.side == 'POSITIVE' else "negative"
            self.report({'INFO'}, f"Aligned to {side_name} {axis_names[axis_index]}")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to align: {e}")
            return {'CANCELLED'}

classes = (
    PIE_MT_Align,
    PIE_OT_AlignSelectedXYZ,
    PIE_OT_AlignToXYZ0,
    PIE_OT_AlignXYZAll,
)

addon_keymaps = []

def register():
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        wm = bpy.context.window_manager
        if wm.keyconfigs.addon:

            km = wm.keyconfigs.addon.keymaps.new(name='Mesh')
            kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS', alt=True)
            kmi.properties.name = "PIE_MT_align"
            addon_keymaps.append((km, kmi))
            
        print("pie_align_menu registered successfully")
        
    except Exception as e:
        print(f"Error registering pie_align_menu: {e}")

def unregister():

    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)

        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        if kc:
            for km, kmi in addon_keymaps:
                km.keymap_items.remove(kmi)
        addon_keymaps.clear()
        
        print("pie_align_menu unregistered successfully")
        
    except Exception as e:
        print(f"Error unregistering pie_align_menu: {e}")

if __name__ == "__main__":
    register()
